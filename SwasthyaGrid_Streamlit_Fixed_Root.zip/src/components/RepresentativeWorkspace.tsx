import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { DepartmentConsole } from './DepartmentConsole';
import { InteractiveCivicMap } from './InteractiveCivicMap';
import { AnalystLab } from './AnalystLab';
import { CivicAIAssistant } from './CivicAIAssistant';
import {
  Building2,
  Layers,
  Activity,
  Sparkles,
  AlertOctagon,
  Clock,
  UserCheck,
  CheckCircle,
  FileSpreadsheet,
} from 'lucide-react';

export type RepTab = 'triage_queue' | 'precision_map' | 'research_lab' | 'escalations' | 'ai_assistant';

export const RepresentativeWorkspace: React.FC = () => {
  const { currentUser, complaints, t, language } = useApp();
  const [activeTab, setActiveTab] = useState<RepTab>('triage_queue');

  const urgentCount = complaints.filter(c => c.currentPriority === 'URGENT' && c.status !== 'RESOLVED').length;
  const overdueCount = complaints.filter(c => c.hoursElapsed >= c.slaDeadlineHours && c.status !== 'RESOLVED').length;
  const disputedCount = complaints.filter(c => c.status === 'REOPENED').length;

  return (
    <div className="space-y-6 my-6">
      {/* Official Department Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white rounded-2xl p-6 border border-slate-700 shadow-xs flex flex-wrap justify-between items-center gap-4">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider">
            <span>Ward Representative & Department Dispatch</span> · <span>Zone 10 Chennai</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight">
            {currentUser.name}
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl">
            Greater Chennai Corporation · Sanitation, Sewerage & Drainage Directorate. Review explainable hazard scores, dispatch field units, and enforce municipal SLAs.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="font-mono text-xs bg-rose-950/60 text-rose-300 border border-rose-800 px-3 py-1.5 rounded-lg font-bold">
            {urgentCount} Urgent Hazards
          </span>
          {overdueCount > 0 && (
            <span className="font-mono text-xs bg-amber-950/60 text-amber-300 border border-amber-800 px-3 py-1.5 rounded-lg font-bold">
              {overdueCount} SLA Breaches
            </span>
          )}
        </div>
      </div>

      {/* Representative Exclusive Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto text-xs font-semibold">
        <button
          type="button"
          onClick={() => setActiveTab('triage_queue')}
          className={`px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'triage_queue'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>Dispatch Queue & Triage</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('precision_map')}
          className={`px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'precision_map'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Precision Spatial Map</span>
          <span className="text-[10px] bg-teal-100 text-teal-800 px-1.5 py-0.2 rounded font-mono">Officer View</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('escalations')}
          className={`px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'escalations'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <AlertOctagon className="w-3.5 h-3.5 text-rose-500" />
          <span>SLA & Escalations</span>
          {(overdueCount > 0 || disputedCount > 0) && (
            <span className="bg-rose-100 text-rose-800 text-[10px] px-1.5 py-0.2 rounded font-bold">
              {overdueCount + disputedCount}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('research_lab')}
          className={`px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'research_lab'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <Activity className="w-3.5 h-3.5 text-teal-400" />
          <span>Intervention Efficacy Lab</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('ai_assistant')}
          className={`px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'ai_assistant'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-teal-400" />
          <span>Municipal AI Dispatcher</span>
        </button>
      </div>

      {/* Tab 1: Dispatch Queue */}
      {activeTab === 'triage_queue' && <DepartmentConsole />}

      {/* Tab 2: Precision Map */}
      {activeTab === 'precision_map' && <InteractiveCivicMap onGoToDepartment={() => setActiveTab('triage_queue')} />}

      {/* Tab 3: Escalations View */}
      {activeTab === 'escalations' && (
        <div className="space-y-4">
          <div className="border border-slate-200 bg-white rounded-xl p-6 shadow-xs space-y-4">
            <div>
              <h3 className="font-bold text-base text-slate-900">Overdue SLAs & Citizen Disputes</h3>
              <p className="text-xs text-slate-500">
                Incidents exceeding standard turnaround times or disputed during community verification.
              </p>
            </div>

            <div className="divide-y divide-slate-100">
              {complaints
                .filter(c => c.hoursElapsed >= c.slaDeadlineHours || c.status === 'REOPENED')
                .map(item => (
                  <div key={item.id} className="py-4 flex flex-wrap justify-between items-start gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-slate-900">{item.trackingNumber}</span>
                        {item.status === 'REOPENED' ? (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-100 text-rose-800">
                            CITIZEN DISPUTED RESOLUTION
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-800">
                            SLA OVERDUE
                          </span>
                        )}
                      </div>
                      <h4 className="font-bold text-sm text-slate-900">{item.title}</h4>
                      <p className="text-xs text-slate-500">{item.addressText}</p>
                    </div>

                    <div className="text-right text-xs space-y-1">
                      <span className="font-mono text-rose-700 font-bold block">
                        Elapsed: {item.hoursElapsed}h / {item.slaDeadlineHours}h
                      </span>
                      <span className="text-slate-500 block">
                        Assigned: {item.assignedOfficerName || 'None'}
                      </span>
                      <button
                        type="button"
                        onClick={() => setActiveTab('triage_queue')}
                        className="bg-slate-900 text-white px-3 py-1 rounded text-[11px] font-semibold cursor-pointer"
                      >
                        Reallocate Dispatch
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Research Lab */}
      {activeTab === 'research_lab' && <AnalystLab />}

      {/* Tab 5: AI Assistant */}
      {activeTab === 'ai_assistant' && <CivicAIAssistant />}
    </div>
  );
};
