import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { evaluateInterventionEffect } from '../services/interventionReassessment';
import { rankEvidenceGapInspections } from '../services/evidenceGapEngine';
import { InspectionCandidate } from '../types';
import {
  TrendingDown,
  AlertOctagon,
  HelpCircle,
  Activity,
  Sliders,
  CheckCircle2,
  FileQuestion,
  ShieldAlert,
  ArrowRight,
} from 'lucide-react';

export const AnalystLab: React.FC = () => {
  const { complaints, interventions, t } = useApp();
  const [activeTab, setActiveTab] = useState<'candidate1' | 'candidate2' | 'trends'>('candidate1');

  // Candidate 1 Interactive Simulator State
  const [baselineCount, setBaselineCount] = useState<number>(14);
  const [postCount, setPostCount] = useState<number>(3);
  const [baselineDays, setBaselineDays] = useState<number>(14);
  const [evalDays, setEvalDays] = useState<number>(14);
  const [rainfallShift, setRainfallShift] = useState<number>(12);

  const reassessResult = evaluateInterventionEffect({
    interventionId: 'sim-001',
    complaintId: 'SG-TN-DEMO',
    type: 'DESILTING',
    completedAt: new Date(),
    baselineWindowDays: baselineDays,
    evaluationWindowDays: evalDays,
    baselineIncidentCount: baselineCount,
    postIncidentCount: postCount,
    rainfallShiftMm: rainfallShift,
  });

  // Candidate 2 Evidence Gap Calculations
  const inspectionCandidates: InspectionCandidate[] = complaints.map(c => ({
    complaintId: c.id,
    trackingNumber: c.trackingNumber,
    priorityScore: c.priorityScore,
    lastInspectedHoursAgo: c.status === 'SUBMITTED' ? -1 : Math.round(c.hoursElapsed),
    hasVerifiedPhoto: Boolean(c.imageUrl),
    hasPreciseGps: Boolean(c.lat && c.lng && c.lat !== 13.0827),
    citizenReportCount: c.independentReportsCount,
    isInterventionPendingCheck: c.status === 'AWAITING_VERIFICATION',
  }));

  const gapRankings = rankEvidenceGapInspections(inspectionCandidates);

  return (
    <div className="bg-white border border-slate-200 rounded-xl shadow-xs p-6 my-6 space-y-6">
      {/* Title & Research Tab Switcher */}
      <div className="flex flex-wrap justify-between items-center pb-4 border-b border-slate-200 gap-3">
        <div>
          <span className="text-[11px] font-bold text-teal-700 uppercase tracking-wider block">
            Academic Research Sandbox
          </span>
          <h3 className="text-xl font-bold text-slate-900 mt-0.5">{t.research.title}</h3>
          <p className="text-xs text-slate-500 mt-0.5">{t.research.subtitle}</p>
        </div>

        <div className="flex bg-slate-100 p-1 rounded-lg text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('candidate1')}
            className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
              activeTab === 'candidate1'
                ? 'bg-white text-slate-950 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            1. Intervention Reassessment
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('candidate2')}
            className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
              activeTab === 'candidate2'
                ? 'bg-white text-slate-950 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            2. Evidence-Gap Prioritization
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('trends')}
            className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
              activeTab === 'trends'
                ? 'bg-white text-slate-950 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Spatio-Temporal Trends
          </button>
        </div>
      </div>

      {/* Tab 1: Novel Research Candidate 1 */}
      {activeTab === 'candidate1' && (
        <div className="space-y-6">
          <div className="bg-slate-900 text-white p-5 rounded-xl border border-slate-800 space-y-2">
            <span className="text-[11px] font-bold text-teal-400 uppercase tracking-wider">
              {t.research.candidate1Title}
            </span>
            <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
              Unlike static municipal ticket systems that assume an intervention permanently solves a hazard, this algorithm models post-intervention hazard persistence by normalizing daily incident velocity across temporal windows and controlling for environmental confounders like localized rainfall surges.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Interactive Parameter Controls */}
            <div className="lg:col-span-1 bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-4 text-xs">
              <div className="flex items-center gap-1.5 font-bold text-slate-800 border-b border-slate-200 pb-2">
                <Sliders className="w-4 h-4 text-teal-600" />
                <span>Simulation Parameter Controls</span>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">
                  Baseline Complaints (Pre-Window): <strong>{baselineCount}</strong>
                </label>
                <input
                  type="range"
                  min="1"
                  max="30"
                  value={baselineCount}
                  onChange={e => setBaselineCount(parseInt(e.target.value))}
                  className="w-full accent-teal-600"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">
                  Post-Intervention Complaints: <strong>{postCount}</strong>
                </label>
                <input
                  type="range"
                  min="0"
                  max="20"
                  value={postCount}
                  onChange={e => setPostCount(parseInt(e.target.value))}
                  className="w-full accent-teal-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-500 block mb-0.5">Pre Days</label>
                  <input
                    type="number"
                    value={baselineDays}
                    onChange={e => setBaselineDays(parseInt(e.target.value) || 1)}
                    className="w-full bg-white border border-slate-300 rounded p-1.5 font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-500 block mb-0.5">Post Days</label>
                  <input
                    type="number"
                    value={evalDays}
                    onChange={e => setEvalDays(parseInt(e.target.value) || 1)}
                    className="w-full bg-white border border-slate-300 rounded p-1.5 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">
                  Precipitation Shift Confounder: <strong>{rainfallShift > 0 ? `+${rainfallShift}` : rainfallShift} mm</strong>
                </label>
                <input
                  type="range"
                  min="-50"
                  max="100"
                  value={rainfallShift}
                  onChange={e => setRainfallShift(parseInt(e.target.value))}
                  className="w-full accent-teal-600"
                />
                <span className="text-[10px] text-slate-400 block mt-0.5">
                  &gt; 40mm indicates major rainfall surge impacting sewer capacity.
                </span>
              </div>
            </div>

            {/* Algorithmic Output Display */}
            <div className="lg:col-span-2 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="border border-slate-200 rounded-xl p-4 bg-slate-50 text-xs">
                  <span className="text-slate-500 font-semibold block">Incident Velocity Delta</span>
                  <p
                    className={`text-2xl font-extrabold font-mono mt-1 ${
                      reassessResult.observedDeltaRatio <= -0.4
                        ? 'text-teal-700'
                        : reassessResult.observedDeltaRatio >= 0.25
                        ? 'text-rose-700'
                        : 'text-amber-700'
                    }`}
                  >
                    {(reassessResult.observedDeltaRatio * 100).toFixed(1)}%
                  </p>
                  <span className="text-[11px] text-slate-500 block mt-0.5">
                    {baselineCount} pre-events vs {postCount} post-events
                  </span>
                </div>

                <div className="border border-slate-200 rounded-xl p-4 bg-slate-50 text-xs">
                  <span className="text-slate-500 font-semibold block">Trend Verdict</span>
                  <p className="text-xl font-extrabold text-slate-900 mt-1">
                    {reassessResult.trendVerdict}
                  </p>
                  <span
                    className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded mt-1 ${
                      reassessResult.confidenceRating === 'HIGH'
                        ? 'bg-teal-100 text-teal-800'
                        : reassessResult.confidenceRating === 'MEDIUM'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    Confidence: {reassessResult.confidenceRating}
                  </span>
                </div>

                <div className="border border-slate-200 rounded-xl p-4 bg-slate-50 text-xs">
                  <span className="text-slate-500 font-semibold block">Identified Confounders</span>
                  <p className="text-xs font-semibold text-slate-800 mt-1">
                    {reassessResult.identifiedConfounders.length === 0
                      ? 'No material confounders detected.'
                      : `${reassessResult.identifiedConfounders.length} confounding factor(s)`}
                  </p>
                </div>
              </div>

              {reassessResult.identifiedConfounders.length > 0 && (
                <div className="p-3 bg-amber-50/80 border border-amber-200 rounded-lg text-xs text-amber-900">
                  <span className="font-bold block flex items-center gap-1">
                    <AlertOctagon className="w-4 h-4 text-amber-700" /> Confounder Audit Notice:
                  </span>
                  <ul className="list-disc list-inside space-y-0.5 mt-1 text-[11px]">
                    {reassessResult.identifiedConfounders.map((c, i) => (
                      <li key={i}>{c}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="p-4 bg-teal-50 border border-teal-200 rounded-lg text-xs text-teal-950 space-y-1">
                <span className="font-bold text-teal-900 block">Algorithmic Recommendation:</span>
                <p className="leading-relaxed">{reassessResult.recommendation}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Novel Research Candidate 2 */}
      {activeTab === 'candidate2' && (
        <div className="space-y-4">
          <div className="bg-slate-900 text-white p-5 rounded-xl border border-slate-800 space-y-2">
            <span className="text-[11px] font-bold text-teal-400 uppercase tracking-wider">
              {t.research.candidate2Title}
            </span>
            <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
              Traditional municipal triage sends inspectors only to the highest claimed severity. This leads to blind spots where reports are critical but lack photographic confirmation, have unverified GPS, or stale evidence. Our Information Gain formula ranks inspections by:
              <br />
              <code className="text-teal-300 font-mono text-[11px]">
                Composite = 0.55 × UrgencyScore + 0.45 × EvidenceGapScore
              </code>
            </p>
          </div>

          <div className="border border-slate-200 rounded-xl overflow-hidden divide-y divide-slate-100">
            {gapRankings.map((target, idx) => (
              <div
                key={target.complaintId}
                className="p-4 bg-white flex flex-col md:flex-row justify-between items-start md:items-center gap-3 hover:bg-slate-50 transition-colors"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-slate-900">
                      #{idx + 1} · {target.trackingNumber}
                    </span>
                    <span className="text-xs bg-rose-100 text-rose-800 font-bold px-2 py-0.5 rounded font-mono">
                      Inspection Priority: {target.compositeInspectionPriority}
                    </span>
                  </div>

                  <ul className="text-xs text-amber-900 space-y-0.5 list-disc list-inside">
                    {target.criticalMissingEvidence.map((gap, gIdx) => (
                      <li key={gIdx}>{gap}</li>
                    ))}
                  </ul>
                </div>

                <div className="text-right text-xs shrink-0 font-mono space-y-0.5">
                  <span className="text-slate-500 block">
                    Operational Urgency: <strong>{target.urgencyScore}</strong>
                  </span>
                  <span className="text-slate-500 block">
                    Uncertainty Gap: <strong>{target.evidenceGapScore}</strong>
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Spatio-Temporal Trends */}
      {activeTab === 'trends' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border border-slate-200 rounded-xl p-4 bg-slate-50 space-y-3">
              <span className="font-bold text-xs text-slate-800 block">
                Category Distribution (Ward 10 Chennai)
              </span>
              <div className="space-y-2 text-xs">
                {Object.entries(t.categories).map(([k, label]) => {
                  const count = complaints.filter(c => c.categoryCode === k).length;
                  const pct = Math.round((count / Math.max(complaints.length, 1)) * 100);
                  return (
                    <div key={k} className="space-y-1">
                      <div className="flex justify-between text-[11px]">
                        <span className="text-slate-700 truncate">{label}</span>
                        <span className="font-mono font-bold text-slate-900">{count} ({pct}%)</span>
                      </div>
                      <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-teal-600 h-full rounded-full transition-all"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="border border-slate-200 rounded-xl p-4 bg-slate-50 space-y-3">
              <span className="font-bold text-xs text-slate-800 block">
                Priority Band Breakdown
              </span>
              <div className="space-y-3 pt-2">
                {[
                  { band: 'URGENT', color: 'bg-rose-600', text: 'text-rose-700' },
                  { band: 'HIGH', color: 'bg-orange-500', text: 'text-orange-700' },
                  { band: 'MODERATE', color: 'bg-amber-500', text: 'text-amber-700' },
                  { band: 'ROUTINE', color: 'bg-emerald-600', text: 'text-emerald-700' },
                ].map(item => {
                  const count = complaints.filter(c => c.currentPriority === item.band).length;
                  const pct = Math.round((count / Math.max(complaints.length, 1)) * 100);
                  return (
                    <div key={item.band} className="flex items-center justify-between text-xs">
                      <span className={`font-bold ${item.text}`}>{item.band}</span>
                      <div className="flex items-center gap-2">
                        <div className="w-32 bg-slate-200 h-2 rounded-full overflow-hidden">
                          <div
                            className={`${item.color} h-full rounded-full`}
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                        <span className="font-mono font-bold text-slate-800 w-12 text-right">
                          {count} ({pct}%)
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
