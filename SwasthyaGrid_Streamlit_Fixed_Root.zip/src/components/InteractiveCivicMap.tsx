import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { useApp } from '../context/AppContext';
import { Complaint, IncidentCluster } from '../types';
import { runDBSCANClustering } from '../services/clustering';
import { MapPin, Shield, Layers, Filter, Eye, AlertOctagon, X, Clock, ExternalLink } from 'lucide-react';

interface InteractiveCivicMapProps {
  onSelectComplaint?: (complaint: Complaint) => void;
  onGoToDepartment?: () => void;
}

export const InteractiveCivicMap: React.FC<InteractiveCivicMapProps> = ({ onSelectComplaint, onGoToDepartment }) => {
  const { complaints, currentUser, t } = useApp();
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const clustersLayerRef = useRef<L.LayerGroup | null>(null);

  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [filterPriority, setFilterPriority] = useState<string>('ALL');
  const [showClusters, setShowClusters] = useState<boolean>(true);
  const [clusters, setClusters] = useState<IncidentCluster[]>([]);

  // Privacy Rule: Mask coordinates by rounding to 3 decimal places for public / citizens
  const isOfficerOrAdmin = ['FIELD_OFFICER', 'DEPT_OFFICER', 'HEALTH_ANALYST', 'SYS_ADMIN'].includes(currentUser.role);

  // Filter complaints
  const displayedComplaints = complaints
    .filter(c => filterCategory === 'ALL' || c.categoryCode === filterCategory)
    .filter(c => filterPriority === 'ALL' || c.currentPriority === filterPriority)
    .map(c => {
      if (isOfficerOrAdmin) return c;
      return {
        ...c,
        lat: Number(c.lat.toFixed(3)),
        lng: Number(c.lng.toFixed(3)),
      };
    });

  // Calculate DBSCAN clusters
  useEffect(() => {
    const points = complaints.map(c => ({
      id: c.id,
      lat: c.lat,
      lng: c.lng,
      category: c.categoryCode,
      timestamp: new Date(c.createdAt).getTime(),
    }));
    const computed = runDBSCANClustering(points, 300, 2, 120);
    setClusters(computed);
  }, [complaints]);

  // Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [13.0845, 80.2718], // Chennai Ward 10 Center
        zoom: 15,
        zoomControl: true,
      });

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19,
      }).addTo(map);

      markersLayerRef.current = L.layerGroup().addTo(map);
      clustersLayerRef.current = L.layerGroup().addTo(map);

      mapInstanceRef.current = map;
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Sync Markers and Cluster Overlays
  useEffect(() => {
    if (!mapInstanceRef.current || !markersLayerRef.current || !clustersLayerRef.current) return;

    markersLayerRef.current.clearLayers();
    clustersLayerRef.current.clearLayers();

    // 1. Render DBSCAN Cluster Overlays
    if (showClusters) {
      clusters.forEach(clust => {
        const circle = L.circle([clust.centroid.lat, clust.centroid.lng], {
          radius: clust.radiusMeters,
          color: '#0d9488',
          fillColor: '#14b8a6',
          fillOpacity: 0.15,
          weight: 2,
          dashArray: '4, 4',
        });

        circle.bindTooltip(
          `<strong>Spatial Cluster (${clust.memberIds.length} hazards)</strong><br/>Dominant: ${clust.dominantCategory}`,
          { permanent: false, direction: 'top' }
        );

        clustersLayerRef.current?.addLayer(circle);
      });
    }

    // 2. Render Incident Pins
    displayedComplaints.forEach(item => {
      const colorMap = {
        URGENT: '#e11d48',
        HIGH: '#ea580c',
        MODERATE: '#d97706',
        ROUTINE: '#059669',
      };
      const pinColor = colorMap[item.currentPriority] || '#475569';

      const customIcon = L.divIcon({
        className: 'custom-map-marker',
        html: `
          <div style="
            background-color: ${pinColor};
            width: 26px;
            height: 26px;
            border-radius: 50%;
            border: 2px solid white;
            box-shadow: 0 2px 8px rgba(0,0,0,0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 11px;
            font-weight: bold;
            cursor: pointer;
          ">
            !
          </div>
        `,
        iconSize: [26, 26],
        iconAnchor: [13, 13],
      });

      const marker = L.marker([item.lat, item.lng], { icon: customIcon });

      marker.on('click', () => {
        setSelectedComplaint(item);
        if (onSelectComplaint) onSelectComplaint(item);
      });

      markersLayerRef.current?.addLayer(marker);
    });
  }, [displayedComplaints, clusters, showClusters, onSelectComplaint]);

  return (
    <div className="bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden my-6">
      {/* Top Filter and Status Toolbar */}
      <div className="p-4 bg-slate-900 text-white flex flex-wrap justify-between items-center gap-3">
        <div className="flex items-center gap-2">
          <Layers className="w-5 h-5 text-teal-400" />
          <div>
            <h3 className="font-bold text-sm tracking-tight">Hyperlocal Civic Risk Visualizer</h3>
            <span className="text-[11px] text-slate-400 block -mt-0.5">
              Chennai Corporation Ward 10 Grid · 13.0845° N, 80.2718° E
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          {/* Privacy badge */}
          {!isOfficerOrAdmin ? (
            <div className="bg-slate-800 text-teal-300 px-2.5 py-1 rounded text-[11px] font-medium flex items-center gap-1 border border-slate-700">
              <Shield className="w-3.5 h-3.5 text-teal-400" />
              <span>Public View: 100m Spatial Privacy Jitter Active</span>
            </div>
          ) : (
            <div className="bg-teal-900/60 text-teal-200 px-2.5 py-1 rounded text-[11px] font-medium flex items-center gap-1 border border-teal-700/50">
              <Eye className="w-3.5 h-3.5 text-teal-300" />
              <span>Officer Precision Mode Enabled</span>
            </div>
          )}

          {/* DBSCAN Clusters Toggle */}
          <button
            type="button"
            onClick={() => setShowClusters(!showClusters)}
            className={`px-2.5 py-1 rounded text-[11px] font-semibold border transition-colors cursor-pointer ${
              showClusters
                ? 'bg-teal-700 border-teal-500 text-white'
                : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
            }`}
          >
            {showClusters ? `Clusters (${clusters.length}) On` : 'Clusters Off'}
          </button>

          {/* Category Filter */}
          <select
            value={filterCategory}
            onChange={e => setFilterCategory(e.target.value)}
            className="bg-slate-800 border border-slate-700 text-white text-xs rounded px-2.5 py-1 outline-hidden"
          >
            <option value="ALL">All Categories ({complaints.length})</option>
            {Object.entries(t.categories).map(([k, label]) => (
              <option key={k} value={k}>
                {label}
              </option>
            ))}
          </select>

          {/* Priority Filter */}
          <select
            value={filterPriority}
            onChange={e => setFilterPriority(e.target.value)}
            className="bg-slate-800 border border-slate-700 text-white text-xs rounded px-2.5 py-1 outline-hidden"
          >
            <option value="ALL">All Priorities</option>
            <option value="URGENT">Urgent Only</option>
            <option value="HIGH">High</option>
            <option value="MODERATE">Moderate</option>
            <option value="ROUTINE">Routine</option>
          </select>
        </div>
      </div>

      {/* Main Map Viewport & Side Inspection Drawer */}
      <div className="relative h-[550px] w-full flex">
        {/* Map Container */}
        <div ref={mapContainerRef} className="w-full h-full z-0" />

        {/* Floating Map Legend */}
        <div className="absolute bottom-4 left-4 z-10 bg-white/95 backdrop-blur-xs border border-slate-200 rounded-lg p-2.5 shadow-sm text-[11px] space-y-1.5 hidden sm:block">
          <span className="font-bold text-slate-700 block">Civic Hazard Priority:</span>
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 font-medium">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-600"></span> Urgent
            </span>
            <span className="flex items-center gap-1 font-medium">
              <span className="w-2.5 h-2.5 rounded-full bg-orange-500"></span> High
            </span>
            <span className="flex items-center gap-1 font-medium">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span> Moderate
            </span>
            <span className="flex items-center gap-1 font-medium">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span> Routine
            </span>
          </div>
        </div>

        {/* Side Inspector Drawer */}
        {selectedComplaint && (
          <div className="absolute top-0 right-0 bottom-0 w-80 sm:w-96 bg-white z-20 border-l border-slate-200 shadow-xl p-5 flex flex-col justify-between overflow-y-auto">
            <div className="space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <span className="font-mono text-xs font-bold text-slate-500 block">
                    {selectedComplaint.trackingNumber}
                  </span>
                  <h4 className="font-bold text-sm text-slate-900 mt-0.5 leading-snug">
                    {selectedComplaint.title}
                  </h4>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedComplaint(null)}
                  className="p-1 text-slate-400 hover:text-slate-700 rounded transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Priority & Status Badges */}
              <div className="flex items-center gap-2">
                <span
                  className={`text-xs font-bold px-2 py-0.5 rounded ${
                    selectedComplaint.currentPriority === 'URGENT'
                      ? 'bg-rose-100 text-rose-800'
                      : selectedComplaint.currentPriority === 'HIGH'
                      ? 'bg-orange-100 text-orange-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {selectedComplaint.currentPriority} (Score: {selectedComplaint.priorityScore})
                </span>
                <span className="text-xs bg-slate-100 text-slate-700 font-semibold px-2 py-0.5 rounded">
                  {t.status[selectedComplaint.status] || selectedComplaint.status}
                </span>
              </div>

              {/* Details List */}
              <div className="space-y-2 text-xs border-t border-b border-slate-100 py-3">
                <div className="flex justify-between">
                  <span className="text-slate-500">Category:</span>
                  <span className="font-semibold text-slate-800 text-right">
                    {t.categories[selectedComplaint.categoryCode as keyof typeof t.categories] || selectedComplaint.categoryCode}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Assigned Officer:</span>
                  <span className="font-semibold text-slate-800 text-right">
                    {selectedComplaint.assignedOfficerName || 'Pending Allocation'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">SLA Progress:</span>
                  <span className="font-mono text-slate-700 text-right flex items-center gap-1">
                    <Clock className="w-3 h-3 text-slate-400" />
                    {selectedComplaint.hoursElapsed}h / {selectedComplaint.slaDeadlineHours}h
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Coordinates:</span>
                  <span className="font-mono text-slate-700 text-right">
                    {selectedComplaint.lat.toFixed(4)}°, {selectedComplaint.lng.toFixed(4)}°
                  </span>
                </div>
              </div>

              {/* Description */}
              <div>
                <span className="text-xs font-bold text-slate-800 block">Citizen Report:</span>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed bg-slate-50 p-2.5 rounded border border-slate-100">
                  {selectedComplaint.description}
                </p>
              </div>

              {/* AI Triage Observations */}
              {selectedComplaint.aiObservations && selectedComplaint.aiObservations.length > 0 && (
                <div className="bg-teal-50/70 border border-teal-200/70 p-3 rounded text-xs">
                  <span className="font-bold text-teal-900 block flex items-center gap-1">
                    Verified AI Observations:
                  </span>
                  <ul className="list-disc list-inside mt-1 space-y-0.5 text-teal-800 text-[11px]">
                    {selectedComplaint.aiObservations.map((obs, idx) => (
                      <li key={idx}>{obs}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Bottom Actions */}
            <div className="pt-4 border-t border-slate-100 space-y-2">
              {onGoToDepartment && (
                <button
                  type="button"
                  onClick={onGoToDepartment}
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white py-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-teal-400" /> Manage in Department Dispatch
                </button>
              )}
              <span className="text-[10px] text-slate-400 block text-center">
                Record ID: {selectedComplaint.id} · Audit Secured
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
