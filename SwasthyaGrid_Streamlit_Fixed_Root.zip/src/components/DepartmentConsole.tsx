import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Complaint, PriorityBand, ComplaintStatus } from '../types';
import {
  Clock,
  UserCheck,
  Filter,
  CheckCircle,
  AlertTriangle,
  ChevronRight,
  ShieldAlert,
  ArrowUpRight,
  Info,
} from 'lucide-react';

export const DepartmentConsole: React.FC = () => {
  const { complaints, updateComplaintStatus, t, language } = useApp();

  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [filterPriority, setFilterPriority] = useState<string>('ALL');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [inspectComplaint, setInspectComplaint] = useState<Complaint | null>(null);

  // Filtered dataset
  const filtered = complaints.filter(c => {
    if (filterCategory !== 'ALL' && c.categoryCode !== filterCategory) return false;
    if (filterPriority !== 'ALL' && c.currentPriority !== filterPriority) return false;
    if (filterStatus !== 'ALL' && c.status !== filterStatus) return false;
    return true;
  });

  const urgentCount = complaints.filter(c => c.currentPriority === 'URGENT' && c.status !== 'RESOLVED').length;
  const slaBreachedCount = complaints.filter(c => c.hoursElapsed >= c.slaDeadlineHours && c.status !== 'RESOLVED').length;
  const verificationCount = complaints.filter(c => c.status === 'AWAITING_VERIFICATION').length;

  const handleAssignOfficer = (complaintId: string, officerName: string) => {
    updateComplaintStatus(complaintId, 'ASSIGNED', 'Assigned field unit for physical on-site triage', officerName);
  };

  const handleAdvanceStatus = (complaintId: string, currentStatus: ComplaintStatus) => {
    let nextStatus: ComplaintStatus = 'ASSIGNED';
    if (currentStatus === 'SUBMITTED') nextStatus = 'ASSIGNED';
    else if (currentStatus === 'ASSIGNED') nextStatus = 'INSPECTION_SCHEDULED';
    else if (currentStatus === 'INSPECTION_SCHEDULED') nextStatus = 'ACTION_IN_PROGRESS';
    else if (currentStatus === 'ACTION_IN_PROGRESS') nextStatus = 'AWAITING_VERIFICATION';
    else if (currentStatus === 'AWAITING_VERIFICATION') nextStatus = 'RESOLVED';

    updateComplaintStatus(complaintId, nextStatus, `Advanced workflow to ${nextStatus}`);
  };

  return (
    <div className="space-y-6 my-6">
      {/* KPI Overview Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            {t.metrics.activeHazards}
          </span>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-extrabold text-slate-900 font-mono">
              {complaints.filter(c => c.status !== 'RESOLVED').length}
            </span>
            <span className="text-xs text-slate-500">Ward 10 Chennai</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-[11px] font-bold text-rose-600 uppercase tracking-wider block">
            {t.metrics.urgentCount}
          </span>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-extrabold text-rose-700 font-mono">{urgentCount}</span>
            <span className="text-xs text-rose-600 font-semibold">&lt; 12h SLA Limit</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-[11px] font-bold text-amber-600 uppercase tracking-wider block">
            SLA Exceeded / Overdue
          </span>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-extrabold text-amber-700 font-mono">{slaBreachedCount}</span>
            <span className="text-xs text-amber-600 font-semibold">Immediate Dispatch</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-[11px] font-bold text-teal-700 uppercase tracking-wider block">
            Awaiting Citizen Verification
          </span>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-extrabold text-teal-700 font-mono">{verificationCount}</span>
            <span className="text-xs text-teal-600 font-semibold">Field Done</span>
          </div>
        </div>
      </div>

      {/* Main Console Data Grid */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        {/* Header & Filter Bar */}
        <div className="p-4 border-b border-slate-200 flex flex-wrap justify-between items-center gap-3 bg-slate-50/50">
          <div>
            <h3 className="font-bold text-base text-slate-900">{t.nav.department}</h3>
            <p className="text-xs text-slate-500">
              Sanitation, Stormwater & Sewerage Dispatch Queue — Greater Chennai Corporation
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={filterPriority}
              onChange={e => setFilterPriority(e.target.value)}
              className="bg-white border border-slate-300 rounded px-2.5 py-1.5 outline-hidden text-xs"
            >
              <option value="ALL">All Priorities</option>
              <option value="URGENT">Urgent Band</option>
              <option value="HIGH">High Band</option>
              <option value="MODERATE">Moderate Band</option>
              <option value="ROUTINE">Routine Band</option>
            </select>

            <select
              value={filterStatus}
              onChange={e => setFilterStatus(e.target.value)}
              className="bg-white border border-slate-300 rounded px-2.5 py-1.5 outline-hidden text-xs"
            >
              <option value="ALL">All Workflow Stages</option>
              <option value="SUBMITTED">Submitted</option>
              <option value="ASSIGNED">Assigned</option>
              <option value="INSPECTION_SCHEDULED">Inspection Scheduled</option>
              <option value="ACTION_IN_PROGRESS">Action In Progress</option>
              <option value="AWAITING_VERIFICATION">Awaiting Verification</option>
              <option value="RESOLVED">Resolved</option>
            </select>

            <select
              value={filterCategory}
              onChange={e => setFilterCategory(e.target.value)}
              className="bg-white border border-slate-300 rounded px-2.5 py-1.5 outline-hidden text-xs"
            >
              <option value="ALL">All Categories</option>
              {Object.entries(t.categories).map(([k, label]) => (
                <option key={k} value={k}>
                  {label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Table View */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-100/70 text-slate-600 uppercase font-bold text-[11px] border-b border-slate-200">
              <tr>
                <th className="p-3">Reference ID</th>
                <th className="p-3">Civic Hazard & Category</th>
                <th className="p-3">Explainable Risk</th>
                <th className="p-3">SLA Status</th>
                <th className="p-3">Assigned Field Unit</th>
                <th className="p-3">Workflow State</th>
                <th className="p-3 text-right">Dispatch Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map(item => {
                const isOverdue = item.hoursElapsed >= item.slaDeadlineHours && item.status !== 'RESOLVED';

                return (
                  <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3 font-mono font-bold text-slate-900 whitespace-nowrap">
                      {item.trackingNumber}
                    </td>

                    <td className="p-3 max-w-xs">
                      <div className="font-semibold text-slate-900 truncate" title={item.title}>
                        {item.title}
                      </div>
                      <div className="text-[11px] text-slate-500 truncate mt-0.5">
                        {t.categories[item.categoryCode as keyof typeof t.categories] || item.categoryCode}
                      </div>
                    </td>

                    <td className="p-3 whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`px-2 py-0.5 rounded font-bold text-[11px] ${
                            item.currentPriority === 'URGENT'
                              ? 'bg-rose-100 text-rose-800'
                              : item.currentPriority === 'HIGH'
                              ? 'bg-orange-100 text-orange-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {item.currentPriority}
                        </span>
                        <span className="font-mono text-slate-500 text-[11px]">
                          ({item.priorityScore.toFixed(3)})
                        </span>
                        <button
                          type="button"
                          onClick={() => setInspectComplaint(item)}
                          className="text-slate-400 hover:text-slate-700 p-0.5"
                          title="View mathematical risk explanation"
                        >
                          <Info className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>

                    <td className="p-3 whitespace-nowrap">
                      <div
                        className={`flex items-center gap-1 font-mono font-medium ${
                          isOverdue ? 'text-rose-600 font-bold' : 'text-slate-600'
                        }`}
                      >
                        <Clock className="w-3.5 h-3.5 text-slate-400" />
                        <span>
                          {item.hoursElapsed}h / {item.slaDeadlineHours}h
                        </span>
                        {isOverdue && <span className="text-[10px] bg-rose-100 px-1 rounded ml-1">BREACH</span>}
                      </div>
                    </td>

                    <td className="p-3 whitespace-nowrap">
                      {item.assignedOfficerName ? (
                        <span className="inline-flex items-center gap-1 bg-teal-50 text-teal-800 border border-teal-200 px-2 py-0.5 rounded font-medium text-[11px]">
                          <UserCheck className="w-3 h-3 text-teal-600" />
                          {item.assignedOfficerName}
                        </span>
                      ) : (
                        <select
                          aria-label="Assign Field Officer"
                          onChange={e => handleAssignOfficer(item.id, e.target.value)}
                          className="bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 text-[11px] rounded px-2 py-1 outline-hidden cursor-pointer"
                        >
                          <option value="">+ Assign Unit</option>
                          <option value="K. Selvam (Field Officer)">K. Selvam (Field Officer)</option>
                          <option value="M. Vasanth (Sanitation Inspector)">M. Vasanth (Sanitation Insp.)</option>
                          <option value="R. Karthik (Drainage Supervisor)">R. Karthik (Drainage Sup.)</option>
                        </select>
                      )}
                    </td>

                    <td className="p-3 whitespace-nowrap">
                      <span className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded font-medium text-[11px]">
                        {t.status[item.status] || item.status}
                      </span>
                    </td>

                    <td className="p-3 text-right whitespace-nowrap">
                      {item.status !== 'RESOLVED' ? (
                        <button
                          type="button"
                          onClick={() => handleAdvanceStatus(item.id, item.status)}
                          className="bg-slate-900 hover:bg-slate-800 text-white px-3 py-1 rounded text-[11px] font-semibold transition-colors cursor-pointer"
                        >
                          {item.status === 'SUBMITTED' && 'Accept & Assign'}
                          {item.status === 'ASSIGNED' && 'Schedule Inspection'}
                          {item.status === 'INSPECTION_SCHEDULED' && 'Start Remediation'}
                          {item.status === 'ACTION_IN_PROGRESS' && 'Mark Ready for Verification'}
                          {item.status === 'AWAITING_VERIFICATION' && 'Finalize Resolution'}
                        </button>
                      ) : (
                        <span className="text-emerald-700 font-semibold inline-flex items-center gap-1">
                          <CheckCircle className="w-3.5 h-3.5" /> Resolved
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Mathematical Risk Score Breakdown Modal */}
      {inspectComplaint && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex justify-between items-start border-b border-slate-100 pb-3">
              <div>
                <span className="font-mono text-xs text-slate-500">
                  {inspectComplaint.trackingNumber}
                </span>
                <h4 className="font-bold text-base text-slate-900 mt-0.5">
                  Explainable Risk Evaluation Model
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setInspectComplaint(null)}
                className="text-slate-400 hover:text-slate-700 font-bold text-lg"
              >
                ✕
              </button>
            </div>

            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs space-y-2">
              <div className="flex justify-between items-center">
                <span className="font-semibold text-slate-700">Calculated Composite Score:</span>
                <span className="font-mono text-base font-extrabold text-slate-900">
                  {inspectComplaint.priorityScore.toFixed(4)}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="font-semibold text-slate-700">Operational Priority Band:</span>
                <span className="font-bold px-2 py-0.5 rounded bg-rose-100 text-rose-800">
                  {inspectComplaint.currentPriority}
                </span>
              </div>
            </div>

            <div className="text-xs space-y-2">
              <span className="font-bold text-slate-800 block">Linear Formula Dimension Weights:</span>
              <div className="space-y-1.5 font-mono text-[11px]">
                <div className="flex justify-between p-1.5 bg-slate-50 rounded">
                  <span>0.25 × Category Baseline Severity</span>
                  <span className="text-slate-700 font-semibold">0.2125</span>
                </div>
                <div className="flex justify-between p-1.5 bg-slate-50 rounded">
                  <span>0.20 × Persistence Duration (Days Active)</span>
                  <span className="text-slate-700 font-semibold">0.1428</span>
                </div>
                <div className="flex justify-between p-1.5 bg-slate-50 rounded">
                  <span>0.20 × Independent Citizen Corroborations</span>
                  <span className="text-slate-700 font-semibold">
                    {((inspectComplaint.independentReportsCount / 6) * 0.2).toFixed(4)}
                  </span>
                </div>
                <div className="flex justify-between p-1.5 bg-slate-50 rounded">
                  <span>0.15 × Public Exposure (School / Hospital Proximity)</span>
                  <span className="text-slate-700 font-semibold">0.1125</span>
                </div>
                <div className="flex justify-between p-1.5 bg-slate-50 rounded">
                  <span>0.10 × SLA Overdue Duration</span>
                  <span className="text-slate-700 font-semibold">0.0500</span>
                </div>
                <div className="flex justify-between p-1.5 bg-slate-50 rounded">
                  <span>0.10 × Inspection Evidence Quality</span>
                  <span className="text-slate-700 font-semibold">0.0850</span>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex justify-end">
              <button
                type="button"
                onClick={() => setInspectComplaint(null)}
                className="bg-slate-900 text-white px-4 py-2 rounded-lg text-xs font-semibold"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
