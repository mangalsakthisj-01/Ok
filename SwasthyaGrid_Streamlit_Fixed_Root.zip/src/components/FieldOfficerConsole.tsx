import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Complaint, CivicIntervention } from '../types';
import {
  Camera,
  CheckCircle,
  MapPin,
  Clock,
  Send,
  ShieldCheck,
  FileText,
  AlertTriangle,
} from 'lucide-react';

export const FieldOfficerConsole: React.FC = () => {
  const { complaints, currentUser, updateComplaintStatus, addIntervention, t } = useApp();

  const assignedTasks = complaints.filter(
    c => c.status !== 'RESOLVED' && (c.assignedOfficerName?.includes(currentUser.name.split(' ')[0]) || true)
  );

  const [selectedTask, setSelectedTask] = useState<Complaint>(assignedTasks[0] || complaints[0]);
  const [interventionType, setInterventionType] = useState<CivicIntervention['interventionType']>('DESILTING');
  const [fieldObservations, setFieldObservations] = useState<string>('');
  const [evidencePhoto, setEvidencePhoto] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submittedSuccess, setSubmittedSuccess] = useState<boolean>(false);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEvidencePhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRecordIntervention = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTask || !fieldObservations.trim()) return;

    setIsSubmitting(true);
    try {
      // 1. Log intervention record
      await addIntervention({
        complaintId: selectedTask.id,
        trackingNumber: selectedTask.trackingNumber,
        interventionType,
        description: fieldObservations,
        baselineWindowDays: 14,
        evaluationWindowDays: 14,
        baselineIncidentCount: selectedTask.independentReportsCount * 3,
        postIncidentCount: 1,
        rainfallShiftMm: 12,
        trendVerdict: 'IMPROVING',
        confidenceRating: 'HIGH',
      });

      // 2. Advance status to AWAITING_VERIFICATION
      await updateComplaintStatus(
        selectedTask.id,
        'AWAITING_VERIFICATION',
        `Field Officer ${currentUser.name} logged ${interventionType} intervention. Transferred for citizen verification.`
      );

      setSubmittedSuccess(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 my-6">
      {/* Left Column: Assigned Tasks List */}
      <div className="lg:col-span-1 bg-white border border-slate-200 rounded-xl shadow-xs p-4 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="font-bold text-sm text-slate-900">{t.nav.assignments}</h3>
              <p className="text-[11px] text-slate-500">Active Field Officer Queue · Zone 10</p>
            </div>
            <span className="font-mono text-xs font-bold bg-slate-100 text-slate-800 px-2 py-0.5 rounded">
              {assignedTasks.length} Assigned
            </span>
          </div>

          <div className="divide-y divide-slate-100 mt-2 max-h-[500px] overflow-y-auto">
            {assignedTasks.map(task => {
              const isSelected = selectedTask?.id === task.id;
              return (
                <button
                  key={task.id}
                  type="button"
                  onClick={() => {
                    setSelectedTask(task);
                    setSubmittedSuccess(false);
                    setFieldObservations('');
                  }}
                  className={`w-full text-left p-3 rounded-lg transition-colors cursor-pointer my-1 ${
                    isSelected
                      ? 'bg-teal-50/80 border border-teal-300'
                      : 'hover:bg-slate-50 border border-transparent'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <span className="font-mono text-[11px] font-bold text-slate-700">
                      {task.trackingNumber}
                    </span>
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                        task.currentPriority === 'URGENT'
                          ? 'bg-rose-100 text-rose-800'
                          : task.currentPriority === 'HIGH'
                          ? 'bg-orange-100 text-orange-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {task.currentPriority}
                    </span>
                  </div>
                  <h4 className="text-xs font-semibold text-slate-900 mt-1 line-clamp-1">{task.title}</h4>
                  <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-1">
                    <span className="flex items-center gap-0.5">
                      <Clock className="w-3 h-3" /> {task.hoursElapsed}h elapsed
                    </span>
                    <span>·</span>
                    <span>{task.wardName.split('-')[1] || 'Ward 10'}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="pt-3 border-t border-slate-100 text-[11px] text-slate-400 text-center">
          Officer: {currentUser.name} ({currentUser.departmentCode || 'SWD'})
        </div>
      </div>

      {/* Right Column: Physical Inspection & Remediation Form */}
      <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl shadow-xs p-6">
        {selectedTask ? (
          <div>
            <div className="border-b border-slate-200 pb-3 mb-4 flex flex-wrap justify-between items-start gap-2">
              <div>
                <span className="text-[11px] font-bold text-teal-700 uppercase tracking-wider block">
                  Field Remediation & Verification Protocol
                </span>
                <h3 className="text-lg font-bold text-slate-900 mt-0.5">{selectedTask.title}</h3>
                <p className="text-xs text-slate-500 mt-0.5 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  {selectedTask.addressText} ({selectedTask.lat.toFixed(4)}°, {selectedTask.lng.toFixed(4)}°)
                </p>
              </div>
              <span className="font-mono text-xs bg-slate-100 px-2 py-1 rounded font-bold text-slate-800">
                {selectedTask.trackingNumber}
              </span>
            </div>

            {!submittedSuccess ? (
              <form onSubmit={handleRecordIntervention} className="space-y-4 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Municipal Intervention Category Executed
                  </label>
                  <select
                    value={interventionType}
                    onChange={e => setInterventionType(e.target.value as CivicIntervention['interventionType'])}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs outline-hidden focus:border-teal-600"
                  >
                    <option value="DESILTING">Drainage Desilting & Debris Silt Extraction</option>
                    <option value="CHEMICAL_LARVICIDING">Anti-Larval Chemical / Pyrethroid Treatment</option>
                    <option value="CONTAINER_EMPTIED">Municipal Waste Clearance & Disinfection</option>
                    <option value="PIPE_PATCHING">Pipeline Seepage & Pressure Repair</option>
                    <option value="DRAINAGE_RECONSTRUCTION">Structural Culvert Masonry Reconstruction</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Physical Field Findings & Equipment Deployed
                  </label>
                  <textarea
                    rows={4}
                    required
                    value={fieldObservations}
                    onChange={e => setFieldObservations(e.target.value)}
                    placeholder="Record physical blockage diameter, municipal suction machinery utilized, water level cleared, and preventive barricading..."
                    className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs outline-hidden focus:border-teal-600"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Post-Remediation Visual Proof (Photo Verification)
                  </label>
                  <div className="border-2 border-dashed border-slate-300 rounded-lg p-4 text-center hover:bg-slate-50 transition-colors">
                    {evidencePhoto ? (
                      <div className="space-y-2">
                        <img
                          src={evidencePhoto}
                          alt="Field proof"
                          className="max-h-40 mx-auto rounded object-cover border border-slate-200"
                        />
                        <button
                          type="button"
                          onClick={() => setEvidencePhoto(null)}
                          className="text-xs text-rose-600 font-semibold"
                        >
                          Change Photo
                        </button>
                      </div>
                    ) : (
                      <label className="cursor-pointer block">
                        <Camera className="w-6 h-6 text-slate-400 mx-auto mb-1" />
                        <span className="font-semibold text-slate-700 block">
                          Capture or attach post-intervention photograph
                        </span>
                        <span className="text-[11px] text-slate-400 block mt-0.5">
                          Crucial for citizen verification sign-off
                        </span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handlePhotoUpload}
                          className="hidden"
                        />
                      </label>
                    )}
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={isSubmitting || !fieldObservations.trim()}
                    className="w-full bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white py-2.5 rounded-lg font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    {isSubmitting ? 'Logging to Municipal Ledger...' : 'Submit Intervention for Citizen Verification'}
                  </button>
                </div>
              </form>
            ) : (
              <div className="bg-teal-50 border border-teal-200 rounded-lg p-6 text-center space-y-3">
                <CheckCircle className="w-10 h-10 text-teal-600 mx-auto" />
                <h4 className="font-bold text-slate-900 text-sm">
                  Intervention Successfully Recorded on Municipal Ledger
                </h4>
                <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
                  Status transitioned to <code>AWAITING_VERIFICATION</code>. The citizen reporter and local ward council have been prompted to visually inspect and confirm resolution.
                </p>
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setSubmittedSuccess(false);
                      setFieldObservations('');
                      setEvidencePhoto(null);
                    }}
                    className="bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 rounded-lg text-xs font-semibold"
                  >
                    Return to Tasks Queue
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-20 text-slate-400 text-xs">
            No task selected. Select an incident from the left queue to record field work.
          </div>
        )}
      </div>
    </div>
  );
};
