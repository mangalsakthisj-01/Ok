import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Sparkles, Send, Bot, User, Copy, Check, ArrowRight, Shield } from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  modelUsed?: string;
}

interface CivicAIAssistantProps {
  onPreFillReport?: (title: string, description: string, category: string) => void;
}

export const CivicAIAssistant: React.FC<CivicAIAssistantProps> = ({ onPreFillReport }) => {
  const { currentUser, language, t } = useApp();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    let initialGreeting = '';
    if (currentUser.role === 'CITIZEN') {
      initialGreeting =
        language === 'ta'
          ? `வணக்கம் ${currentUser.name}! நான் உங்கள் ஸ்வஸ்த்யாகிரிட் குடிமக்கள் AI உதவியாளர். கழிவுநீர் அடைப்பு, குடிநீர் மாசுபாடு குறித்த புகார்களை பதிவு செய்ய அல்லது நகராட்சி காலக்கெடு (SLA) பற்றி அறிய என்னிடம் கேளுங்கள்.`
          : `Hello ${currentUser.name}! I am your SwasthyaGrid Civic AI Assistant. I can draft official complaints for Chennai Corporation Ward 10, explain resolution SLAs, or advise on immediate household water safety precautions.`;
    } else if (currentUser.role === 'FIELD_OFFICER') {
      initialGreeting =
        language === 'ta'
          ? `வணக்கம் தோழர் ${currentUser.name}! களப்பணி SOP, தூர்வாருதல் உபகரணங்கள் மற்றும் கொசுப்புழு ஒழிப்பு மருந்து அளவீடுகள் பற்றி வழிகாட்ட தயாராக உள்ளேன்.`
          : `Field Unit Online, Officer ${currentUser.name}. I can assist with culvert desilting SOPs, confined-space manhole entry safety checks, or chemical larvicide dilution ratios (BTI/Pyrethrum).`;
    } else {
      initialGreeting =
        language === 'ta'
          ? `வணக்கம் செயற்பொறியாளர் ${currentUser.name}! வார்டு 10 இடர் முன்னுரிமை, SLA காலக்கெடு மீறல்கள் மற்றும் களப்பணி ஒதுக்கீட்டு பகுப்பாய்வை வழங்க தயாராக உள்ளேன்.`
          : `Greetings, Representative/Officer ${currentUser.name}. I am ready to summarize Ward 10 incident velocities, highlight overdue desilting SLAs, or suggest emergency water diversion protocols.`;
    }

    return [
      {
        id: '1',
        sender: 'assistant',
        text: initialGreeting,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ];
  });

  const [input, setInput] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Suggested prompts per role
  const suggestedPrompts =
    currentUser.role === 'CITIZEN'
      ? [
          'Help me draft a clear complaint about a stagnant water mosquito pool.',
          'Draft a complaint for raw sewage overflow on school street.',
          'What should I do if tap water in Ward 10 smells like sewage?',
          'How fast does Chennai Corporation respond to blocked drainage?',
        ]
      : currentUser.role === 'FIELD_OFFICER'
      ? [
          'What is the standard procedure for desilting a 600mm stormwater culvert?',
          'What is the recommended BTI larvicide dosage per square meter of water?',
          'Generate a safety checklist before opening a subterranean sewer manhole.',
        ]
      : [
          'Summarize top urgent civic hazards in Ward 10 Chennai Central.',
          'Which areas show repeating vector hazards and require escalated fogging?',
          'Draft an emergency maintenance notice for Stephenson Road pipeline breach.',
        ];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const handleSend = async (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Math.random().toString(36).substring(2, 9),
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/ai/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          role: currentUser.role,
          language,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const botMsg: ChatMessage = {
          id: Math.random().toString(36).substring(2, 9),
          sender: 'assistant',
          text: data.reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          modelUsed: data.modelUsed,
        };
        setMessages(prev => [...prev, botMsg]);
      } else {
        throw new Error('Failed to get AI assistant response');
      }
    } catch {
      const fallbackMsg: ChatMessage = {
        id: Math.random().toString(36).substring(2, 9),
        sender: 'assistant',
        text: 'Civic Assistant service temporarily unavailable. For immediate municipal emergencies in Ward 10, reach Greater Chennai Corporation at 1913.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  // Helper to render formatted text with headers, bold, bullets
  const renderMessageContent = (text: string) => {
    const lines = text.split('\n');
    return (
      <div className="space-y-1.5 leading-relaxed text-xs">
        {lines.map((line, idx) => {
          if (line.startsWith('### ')) {
            return (
              <h4 key={idx} className="font-bold text-sm text-slate-900 mt-2 mb-1 border-b border-slate-200/60 pb-1">
                {line.replace('### ', '')}
              </h4>
            );
          }
          if (line.startsWith('**') && line.endsWith('**')) {
            return (
              <div key={idx} className="font-bold text-slate-800">
                {line.replace(/\*\*/g, '')}
              </div>
            );
          }
          if (line.startsWith('> ')) {
            return (
              <blockquote
                key={idx}
                className="bg-slate-100/80 p-2.5 rounded-lg border border-slate-200 text-slate-700 italic my-1"
              >
                {line.replace('> ', '')}
              </blockquote>
            );
          }
          if (line.startsWith('- ') || line.startsWith('* ')) {
            return (
              <div key={idx} className="flex items-start gap-1.5 pl-1">
                <span className="text-teal-600 font-bold">•</span>
                <span>{formatInlineBold(line.replace(/^[-*]\s+/, ''))}</span>
              </div>
            );
          }
          if (/^\d+\.\s+/.test(line)) {
            return (
              <div key={idx} className="flex items-start gap-1.5 pl-1">
                <span className="text-slate-500 font-semibold">{line.match(/^\d+\./)?.[0]}</span>
                <span>{formatInlineBold(line.replace(/^\d+\.\s+/, ''))}</span>
              </div>
            );
          }
          if (line.trim() === '---') {
            return <hr key={idx} className="border-slate-200 my-2" />;
          }
          if (!line.trim()) {
            return <div key={idx} className="h-1" />;
          }
          return <div key={idx}>{formatInlineBold(line)}</div>;
        })}
      </div>
    );
  };

  const formatInlineBold = (str: string) => {
    const parts = str.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i} className="font-semibold text-slate-900">{part.slice(2, -2)}</strong>;
      }
      return part;
    });
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden my-6 flex flex-col h-[650px]">
      {/* Assistant Header */}
      <div className="bg-slate-900 text-white p-4 border-b border-slate-800 flex flex-wrap justify-between items-center gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-teal-500/20 border border-teal-400/30 flex items-center justify-center text-teal-300">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-sm tracking-tight flex items-center gap-2">
              <span>SwasthyaGrid Civic AI Assistant</span>
              <span className="text-[10px] bg-teal-950 text-teal-300 border border-teal-800 px-2 py-0.2 rounded font-mono font-medium">
                {currentUser.role}
              </span>
            </h3>
            <span className="text-[11px] text-teal-400 font-mono block -mt-0.5">
              Hyperlocal Civic Intelligence & Tamil Nadu Municipal Regulations
            </span>
          </div>
        </div>

        <div className="text-[10px] text-slate-400 bg-slate-800 px-2.5 py-1 rounded border border-slate-700 hidden sm:block">
          Ward 10 Knowledge Grounded
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 p-4 sm:p-5 overflow-y-auto space-y-4 bg-slate-50/50">
        {messages.map(msg => {
          const isUser = msg.sender === 'user';
          const hasDraft = msg.text.includes('###') || msg.text.includes('Subject:') || msg.text.includes('பொருள்:');

          return (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : ''}`}
            >
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-xs font-bold ${
                  isUser
                    ? 'bg-slate-900 text-white'
                    : 'bg-teal-700 text-teal-100 border border-teal-600'
                }`}
              >
                {isUser ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
              </div>

              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 text-xs shadow-xs ${
                  isUser
                    ? 'bg-slate-900 text-white rounded-tr-xs'
                    : 'bg-white border border-slate-200 text-slate-800 rounded-tl-xs'
                }`}
              >
                {isUser ? (
                  <div className="whitespace-pre-wrap">{msg.text}</div>
                ) : (
                  <div>
                    {renderMessageContent(msg.text)}

                    {/* Copy and Actions for generated drafts */}
                    {hasDraft && (
                      <div className="mt-3 pt-2.5 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                        <button
                          type="button"
                          onClick={() => handleCopy(msg.id, msg.text)}
                          className="bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 px-2.5 py-1 rounded text-[11px] font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                        >
                          {copiedId === msg.id ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-teal-600" />
                              <span className="text-teal-700">Copied to Clipboard!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5 text-slate-500" />
                              <span>Copy Complaint Draft</span>
                            </>
                          )}
                        </button>

                        <span className="text-[10px] text-slate-400">
                          Ready for official GCC submission
                        </span>
                      </div>
                    )}
                  </div>
                )}

                <div className="flex items-center justify-between text-[9px] text-slate-400 mt-1.5 pt-1">
                  <span>{msg.timestamp}</span>
                  {!isUser && msg.modelUsed && (
                    <span className="font-mono text-[9px] text-slate-400">
                      {msg.modelUsed === 'gemini-3.8-flash' ? 'Gemini 3.8 Flash' : 'Civic Knowledge Engine'}
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-center gap-2 text-slate-500 text-xs italic pl-10 py-2">
            <Sparkles className="w-3.5 h-3.5 text-teal-600 animate-spin" />
            <span>Analyzing municipal framework & synthesizing response...</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Questions */}
      <div className="px-4 py-2.5 bg-slate-100/80 border-t border-slate-200 flex items-center gap-2 overflow-x-auto text-[11px]">
        <span className="text-slate-400 font-bold shrink-0 uppercase tracking-wider text-[10px]">
          Suggested:
        </span>
        {suggestedPrompts.map((p, i) => (
          <button
            key={i}
            type="button"
            onClick={() => handleSend(p)}
            className="bg-white hover:bg-teal-50 hover:border-teal-400 border border-slate-300 text-slate-700 px-3 py-1 rounded-full whitespace-nowrap transition-all cursor-pointer shrink-0 shadow-2xs"
          >
            {p}
          </button>
        ))}
      </div>

      {/* Input Box */}
      <div className="p-3.5 bg-white border-t border-slate-200">
        <form
          onSubmit={e => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            placeholder={
              currentUser.role === 'CITIZEN'
                ? 'Ask me to draft a complaint, explain SLAs, or provide water safety advice...'
                : currentUser.role === 'FIELD_OFFICER'
                ? 'Ask for culvert desilting SOPs, chemical mixing dosages, or gas safety checks...'
                : 'Ask for ward triage summaries, urgent priority dispatches, or SLA notices...'
            }
            className="flex-1 border border-slate-300 rounded-lg px-3.5 py-2.5 text-xs outline-hidden focus:border-teal-600 focus:ring-1 focus:ring-teal-600"
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white px-4 py-2.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Send</span>
          </button>
        </form>
      </div>
    </div>
  );
};
