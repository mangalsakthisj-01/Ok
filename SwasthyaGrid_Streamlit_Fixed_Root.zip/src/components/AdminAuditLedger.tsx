import React from 'react';
import { useApp } from '../context/AppContext';
import { ShieldCheck, Lock, Terminal, FileCode, CheckCircle2 } from 'lucide-react';

export const AdminAuditLedger: React.FC = () => {
  const { auditLogs, t } = useApp();

  return (
    <div className="bg-white border border-slate-200 rounded-xl shadow-xs p-6 my-6 space-y-4">
      <div className="flex flex-wrap justify-between items-center pb-4 border-b border-slate-200 gap-3">
        <div>
          <span className="text-[11px] font-bold text-teal-700 uppercase tracking-wider block">
            System Administration & Security Governance
          </span>
          <h3 className="text-xl font-bold text-slate-900 mt-0.5">{t.nav.audit}</h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Tamper-evident, immutable transaction trail recording all role actions, state transitions, and dispatched tasks.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-100 border border-slate-200 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700">
          <ShieldCheck className="w-4 h-4 text-teal-600" />
          <span>Cryptographic Hash Integrity Active</span>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs text-slate-700">
          <thead className="bg-slate-50 text-slate-500 uppercase font-bold text-[11px] border-b border-slate-200">
            <tr>
              <th className="p-3">Timestamp (UTC)</th>
              <th className="p-3">Actor & Role</th>
              <th className="p-3">Action Type</th>
              <th className="p-3">Target Entity</th>
              <th className="p-3">Metadata Snapshot</th>
              <th className="p-3 text-right">Client IP</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
            {auditLogs.map(log => (
              <tr key={log.id} className="hover:bg-slate-50/80">
                <td className="p-3 text-slate-600 whitespace-nowrap">
                  {new Date(log.createdAt).toLocaleString()}
                </td>

                <td className="p-3 font-sans whitespace-nowrap">
                  <div className="font-semibold text-slate-900">{log.actorName}</div>
                  <span className="text-[10px] text-teal-700 font-mono">{log.actorRole}</span>
                </td>

                <td className="p-3 whitespace-nowrap">
                  <span className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded font-bold">
                    {log.actionType}
                  </span>
                </td>

                <td className="p-3 text-slate-700 whitespace-nowrap">
                  {log.entityName} · <span className="font-semibold">{log.entityId}</span>
                </td>

                <td className="p-3 max-w-xs font-sans text-xs">
                  {log.metadata ? (
                    <span className="text-slate-600 truncate block font-mono text-[10px]">
                      {JSON.stringify(log.metadata)}
                    </span>
                  ) : (
                    <span className="text-slate-400">N/A</span>
                  )}
                </td>

                <td className="p-3 text-right text-slate-500 whitespace-nowrap font-mono">
                  {log.ipAddress}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
