import React, { useState } from 'react';
import { useApp, PRESET_USERS } from '../context/AppContext';
import { UserRole } from '../types';
import {
  Shield,
  UserCheck,
  Building2,
  HardHat,
  Globe,
  ArrowRight,
  Lock,
  Mail,
  CheckCircle2,
  Sparkles,
  Info,
} from 'lucide-react';

export const LoginPortal: React.FC = () => {
  const { login, language, setLanguage, t } = useApp();

  const [selectedRole, setSelectedRole] = useState<UserRole>('CITIZEN');
  const [email, setEmail] = useState<string>(PRESET_USERS.CITIZEN.defaultEmail);
  const [password, setPassword] = useState<string>('password123');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleRoleSelect = (role: UserRole) => {
    setSelectedRole(role);
    setEmail(PRESET_USERS[role].defaultEmail);
    setPassword('password123');
    setErrorMsg(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMsg(null);

    try {
      const ok = await login(email, password, selectedRole);
      if (!ok) {
        setErrorMsg('Authentication error. For demo accounts use password: password123');
      }
    } catch {
      setErrorMsg('Network error connecting to authentication server.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickLogin = async (role: UserRole) => {
    handleRoleSelect(role);
    setIsLoading(true);
    await login(PRESET_USERS[role].defaultEmail, 'password123', role);
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-between font-sans selection:bg-teal-500 selection:text-white">
      {/* Top Academic & Demonstration Header */}
      <div className="bg-slate-950/80 border-b border-slate-800 text-xs px-4 sm:px-6 py-2 flex flex-wrap justify-between items-center gap-3">
        <div className="flex items-center gap-2">
          <span className="bg-amber-500/20 text-amber-300 font-bold px-2 py-0.5 rounded border border-amber-500/40 text-[10px] tracking-wide">
            DEMONSTRATION PROTOTYPE
          </span>
          <span className="text-slate-400 text-[11px] truncate">
            {t.academicNotice}
          </span>
        </div>

        <button
          type="button"
          onClick={() => setLanguage(language === 'en' ? 'ta' : 'en')}
          className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-white transition-colors cursor-pointer"
        >
          <Globe className="w-3.5 h-3.5 text-teal-400" />
          <span className="font-semibold">{language === 'en' ? 'தமிழ் (TA)' : 'English (EN)'}</span>
        </button>
      </div>

      {/* Main Login Card Area */}
      <div className="flex-1 flex items-center justify-center p-4 sm:p-6">
        <div className="max-w-xl w-full bg-slate-950/90 border border-slate-800 rounded-2xl shadow-2xl p-6 sm:p-8 space-y-6 backdrop-blur-md">
          {/* Official Emblem & Branding */}
          <div className="text-center space-y-2">
            <div className="w-14 h-14 bg-gradient-to-tr from-slate-900 to-teal-800 border border-teal-500/40 rounded-xl flex items-center justify-center mx-auto text-teal-300 font-extrabold text-xl shadow-lg shadow-teal-950/50">
              SG
            </div>
            <div>
              <h1 className="text-2xl font-extrabold tracking-tight text-white">
                {t.platformName} (ஸ்வஸ்த்யாகிரிட்)
              </h1>
              <p className="text-xs text-teal-400 font-medium mt-0.5">
                {language === 'ta'
                  ? 'நகராட்சி சுகாதாரம் & பொது நல்வாழ்வு நுண்ணறிவு தளம் · சென்னை மாநகராட்சி'
                  : 'Civic Health Intelligence & Municipal Response Platform · Greater Chennai Corporation'}
              </p>
            </div>
          </div>

          {/* Role Selection Tabs */}
          <div className="space-y-2">
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider text-center">
              {language === 'ta' ? 'உள்நுழைய வேண்டிய பயனர் வகையைத் தேர்ந்தெடுக்கவும்:' : 'Choose Authorized User Access Type:'}
            </label>

            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => handleRoleSelect('CITIZEN')}
                className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                  selectedRole === 'CITIZEN'
                    ? 'bg-teal-950/70 border-teal-500 text-teal-200 ring-2 ring-teal-500/30'
                    : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                }`}
              >
                <UserCheck className="w-5 h-5 text-teal-400" />
                <span className="text-xs font-bold block leading-tight">
                  {language === 'ta' ? 'குடிமகன்' : 'Citizen'}
                </span>
                <span className="text-[10px] text-slate-400 block -mt-0.5">
                  {language === 'ta' ? 'புகார் & வரைபடம்' : 'Report & Map'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => handleRoleSelect('DEPT_OFFICER')}
                className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                  selectedRole === 'DEPT_OFFICER'
                    ? 'bg-teal-950/70 border-teal-500 text-teal-200 ring-2 ring-teal-500/30'
                    : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                }`}
              >
                <Building2 className="w-5 h-5 text-teal-400" />
                <span className="text-xs font-bold block leading-tight">
                  {language === 'ta' ? 'துறை அதிகாரி' : 'Representative'}
                </span>
                <span className="text-[10px] text-slate-400 block -mt-0.5">
                  {language === 'ta' ? 'துறை மேலாண்மை' : 'Dispatch / SLA'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => handleRoleSelect('FIELD_OFFICER')}
                className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                  selectedRole === 'FIELD_OFFICER'
                    ? 'bg-teal-950/70 border-teal-500 text-teal-200 ring-2 ring-teal-500/30'
                    : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                }`}
              >
                <HardHat className="w-5 h-5 text-teal-400" />
                <span className="text-xs font-bold block leading-tight">
                  {language === 'ta' ? 'கள அதிகாரி' : 'Field Officer'}
                </span>
                <span className="text-[10px] text-slate-400 block -mt-0.5">
                  {language === 'ta' ? 'கள ஆய்வு & பணி' : 'Tasks & Logs'}
                </span>
              </button>
            </div>
          </div>

          {/* Role Feature Isolation Notice */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3 text-xs text-slate-300 space-y-1">
            <span className="text-[11px] font-bold text-teal-400 flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5" />
              {language === 'ta' ? 'பயனர் பொறுப்பு தனித்துவம்:' : 'Strict Role-Specific UI Workspace:'}
            </span>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              {selectedRole === 'CITIZEN' &&
                (language === 'ta'
                  ? 'குடிமக்களுக்கான பிரத்யேக தளம்: புகார் பதிவு, கண்காணிப்பு, பொது சுகாதார வரைபடம் (100மீ தனியுரிமை பாதுகாப்பு), மற்றும் சமூக உறுதிப்படுத்தல் மட்டுமே காண்பிக்கப்படும்.'
                  : 'Citizen Dedicated Workspace: File complaints, GPS location, personal tracking history, 100m privacy-jittered map, and community verification loop.')}
              {selectedRole === 'DEPT_OFFICER' &&
                (language === 'ta'
                  ? 'துறை அதிகாரிகளுக்கான பிரத்யேக தளம்: வார்டு 10 ஒதுக்கீடுகள், SLA காலக்கெடு, களப்பணி அதிகாரிகளை நியமித்தல், துல்லியமான வரைபடம் மற்றும் இடர் பகுப்பாய்வு.'
                  : 'Ward Representative / Officer Workspace: SLA countdown triage, officer dispatch allocation, unjittered precision geospatial view, and overdue escalation tracking.')}
              {selectedRole === 'FIELD_OFFICER' &&
                (language === 'ta'
                  ? 'கள அதிகாரிகளுக்கான தளம்: தங்களுக்கு ஒதுக்கப்பட்ட பணிகள், தூர்வாருதல்/கொசு மருந்து தெளிப்பு பதிவு, முன்/பின் புகைப்படங்கள் பதிவேற்றம் மற்றும் சரிபார்ப்பு சமர்ப்பிப்பு.'
                  : 'Field Ground Unit Workspace: Real-time work order queue, mobile-friendly on-site inspection logging, photographic evidence upload, and intervention recording.')}
            </p>
          </div>

          {/* Credentials Form */}
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            {errorMsg && (
              <div className="p-3 bg-rose-950/50 border border-rose-800 text-rose-300 rounded-lg text-xs">
                {errorMsg}
              </div>
            )}

            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                {language === 'ta' ? 'மின்னஞ்சல் / அடையாள எண்' : 'Email / Municipal Identifier'}
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                <input
                  type="text"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-3 py-2.5 text-xs text-white outline-hidden focus:border-teal-500 font-mono"
                  placeholder="name@swasthyagrid.tn.gov.in"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                {language === 'ta' ? 'கடவுச்சொல்' : 'Password'}
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-3 py-2.5 text-xs text-white outline-hidden focus:border-teal-500 font-mono"
                  placeholder="••••••••••••"
                />
              </div>
              <span className="text-[10px] text-slate-500 block mt-1">
                Demo access code: <code>password123</code>
              </span>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white font-bold py-2.5 rounded-lg text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-md shadow-teal-950"
            >
              {isLoading ? (
                <span>Authenticating Credentials...</span>
              ) : (
                <>
                  <span>
                    {language === 'ta'
                      ? `${PRESET_USERS[selectedRole].roleLabelTa} ஆக உள்நுழையவும்`
                      : `Sign In to ${PRESET_USERS[selectedRole].roleLabel} Workspace`}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Quick-Access 1-Click Fast Logins for instant evaluation */}
          <div className="border-t border-slate-800 pt-4 space-y-2">
            <span className="text-[11px] font-bold text-slate-400 block text-center uppercase tracking-wider">
              {language === 'ta' ? 'ஒரு நொடியில் உள்நுழைய (மாதிரி கணக்குகள்):' : '1-Click Instant Evaluator Sign-In:'}
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => handleQuickLogin('CITIZEN')}
                className="bg-slate-900 hover:bg-slate-800 border border-slate-700 p-2 rounded-lg text-left transition-colors cursor-pointer"
              >
                <span className="text-teal-400 font-bold text-[11px] block">Citizen M. Anand</span>
                <span className="text-[10px] text-slate-400 block">Resident Ward 10</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickLogin('DEPT_OFFICER')}
                className="bg-slate-900 hover:bg-slate-800 border border-slate-700 p-2 rounded-lg text-left transition-colors cursor-pointer"
              >
                <span className="text-teal-400 font-bold text-[11px] block">R. Priya (AEE)</span>
                <span className="text-[10px] text-slate-400 block">Ward Dispatch</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickLogin('FIELD_OFFICER')}
                className="bg-slate-900 hover:bg-slate-800 border border-slate-700 p-2 rounded-lg text-left transition-colors cursor-pointer"
              >
                <span className="text-teal-400 font-bold text-[11px] block">K. Selvam (Field)</span>
                <span className="text-[10px] text-slate-400 block">Zone 10 Ground Unit</span>
              </button>
            </div>

            <div className="flex justify-center gap-4 pt-2 text-[11px] text-slate-500">
              <button
                type="button"
                onClick={() => handleQuickLogin('HEALTH_ANALYST')}
                className="hover:text-slate-300 transition-colors cursor-pointer"
              >
                Epidemiologist (Dr. Kugan)
              </button>
              <span>·</span>
              <button
                type="button"
                onClick={() => handleQuickLogin('SYS_ADMIN')}
                className="hover:text-slate-300 transition-colors cursor-pointer"
              >
                System Admin (Audit Ledger)
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="border-t border-slate-800 p-4 text-center text-xs text-slate-500">
        Greater Chennai Corporation · Tamil Nadu Urban Sanitation Framework · Powered by Gemini 3.8 Flash
      </div>
    </div>
  );
};
