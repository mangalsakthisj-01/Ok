import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { AICategorizationResponse, RiskEvaluationResult } from '../types';
import {
  MapPin,
  Upload,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  AlertTriangle,
  Camera,
  Layers,
  Copy,
  ExternalLink,
} from 'lucide-react';

interface CitizenReportWizardProps {
  onGoToMap?: () => void;
}

export const CitizenReportWizard: React.FC<CitizenReportWizardProps> = ({ onGoToMap }) => {
  const { t, language, addComplaint } = useApp();
  const [step, setStep] = useState<number>(1);

  // Form State
  const [category, setCategory] = useState<string>('sewage_overflow');
  const [title, setTitle] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [coords, setCoords] = useState<{ lat: number; lng: number }>({ lat: 13.0845, lng: 80.2718 });
  const [addressText, setAddressText] = useState<string>('Near Perambur Barracks Road Market, Chennai');
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  // AI & Risk Evaluation State
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [aiAnalysis, setAiAnalysis] = useState<AICategorizationResponse | null>(null);
  const [calculatedRisk, setCalculatedRisk] = useState<RiskEvaluationResult | null>(null);

  // Completion State
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submittedId, setSubmittedId] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);

  // Geolocation Handler
  const handleAcquireLocation = () => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser.');
      return;
    }
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      pos => {
        setCoords({
          lat: Number(pos.coords.latitude.toFixed(6)),
          lng: Number(pos.coords.longitude.toFixed(6)),
        });
        setAddressText(`GPS Coordinates: ${pos.coords.latitude.toFixed(4)}° N, ${pos.coords.longitude.toFixed(4)}° E`);
        setIsLocating(false);
      },
      err => {
        console.warn('Geolocation acquisition failed; using Chennai default grid.', err);
        setIsLocating(false);
      },
      { timeout: 8000 }
    );
  };

  // Image Upload with base64 conversion
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 8 * 1024 * 1024) {
        alert('File size exceeds 8MB limit.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Trigger Gemini Analysis & Risk Scoring
  const triggerAiReview = async () => {
    setIsAnalyzing(true);
    try {
      const base64Data = imagePreview || undefined;

      // Call server-side Gemini classification
      const res = await fetch('/api/ai/classify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title,
          description,
          category,
          imageBase64: base64Data,
        }),
      });

      if (res.ok) {
        const data: AICategorizationResponse = await res.json();
        setAiAnalysis(data);
        if (data.suggestedCategory && data.suggestedCategory !== category) {
          setCategory(data.suggestedCategory);
        }
      }

      // Compute deterministic risk score
      const riskRes = await fetch('/api/risk/evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          severityWeight: category === 'water_supply_contamination' ? 0.95 : category === 'sewage_overflow' ? 0.85 : 0.65,
          persistenceDays: 3,
          independentReportsCount: 1,
          exposureIndex: 0.75, // proximity to public area
          unresolvedDurationDays: 0,
          evidenceQuality: imagePreview ? 0.85 : 0.45,
        }),
      });

      if (riskRes.ok) {
        const riskData = await riskRes.json();
        setCalculatedRisk(riskData);
      }
    } catch (err) {
      console.warn('AI evaluation service call failed; using fallback evaluation.', err);
    } finally {
      setIsAnalyzing(false);
      setStep(4);
    }
  };

  const handleFinalSubmit = async () => {
    setIsSubmitting(true);
    try {
      const created = await addComplaint({
        title,
        description,
        categoryCode: category,
        lat: coords.lat,
        lng: coords.lng,
        addressText,
        imageUrl: imagePreview || undefined,
        currentPriority: aiAnalysis?.suggestedUrgency || calculatedRisk?.band || 'HIGH',
        priorityScore: calculatedRisk?.score || 0.72,
        aiSummary: aiAnalysis?.summary,
        aiObservations: aiAnalysis?.extractedObservations,
        aiMissingInfo: aiAnalysis?.missingInformation,
        aiLimitations: aiAnalysis?.limitations,
      });

      setSubmittedId(created.trackingNumber);
      setStep(5);
    } catch (e) {
      console.error(e);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCopyId = () => {
    if (submittedId) {
      navigator.clipboard.writeText(submittedId);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden my-6">
      {/* Step Header */}
      <div className="bg-slate-900 text-white p-6 flex flex-wrap justify-between items-center gap-3">
        <div>
          <span className="text-[11px] font-semibold tracking-wider text-teal-400 uppercase">
            Citizen Civic Incident Reporting
          </span>
          <h2 className="text-xl font-bold mt-0.5">{t.nav.reportIssue}</h2>
        </div>
        <div className="flex items-center gap-2">
          {[1, 2, 3, 4, 5].map(s => (
            <div
              key={s}
              className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                step === s
                  ? 'bg-teal-500 text-slate-950 font-extrabold ring-2 ring-teal-300'
                  : step > s
                  ? 'bg-slate-700 text-teal-300'
                  : 'bg-slate-800 text-slate-500'
              }`}
            >
              {step > s ? '✓' : s}
            </div>
          ))}
        </div>
      </div>

      <div className="p-6">
        {/* Step 1: Category Selection */}
        {step === 1 && (
          <div className="space-y-4">
            <div>
              <h3 className="font-bold text-base text-slate-900">1. {t.forms.step1}</h3>
              <p className="text-xs text-slate-500 mt-1">
                Select the municipal sanitation or infrastructure category matching your observation:
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {Object.entries(t.categories).map(([key, label]) => {
                const isSelected = category === key;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setCategory(key)}
                    className={`p-4 rounded-lg border text-left transition-all flex items-start justify-between gap-2 cursor-pointer ${
                      isSelected
                        ? 'border-teal-600 bg-teal-50/60 ring-2 ring-teal-500/20 text-slate-950'
                        : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700'
                    }`}
                  >
                    <div>
                      <span className="text-xs font-bold block">{label}</span>
                      <span className="text-[11px] text-slate-500 mt-0.5 block">
                        {key === 'sewage_overflow' && 'Leaking manholes, open drainage gutters'}
                        {key === 'stagnant_water' && 'Mosquito vector breeding, unemptied pools'}
                        {key === 'garbage_accumulation' && 'Uncollected solid waste heaps, overflowing bins'}
                        {key === 'blocked_drainage' && 'Choked stormwater canals and culverts'}
                        {key === 'water_supply_contamination' && 'Discolored or foul smelling tap supply'}
                        {key === 'damaged_infrastructure' && 'Broken manhole covers, cracked public conduits'}
                        {key === 'unsanitary_public_toilet' && 'Unmaintained municipal sanitary facilities'}
                      </span>
                    </div>
                    {isSelected && <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />}
                  </button>
                );
              })}
            </div>

            <div className="flex justify-end pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="bg-slate-900 hover:bg-slate-800 text-white px-5 py-2.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                {t.forms.nextBtn}: {t.forms.step2} <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Location Selection */}
        {step === 2 && (
          <div className="space-y-4">
            <div>
              <h3 className="font-bold text-base text-slate-900">2. {t.forms.step2}</h3>
              <p className="text-xs text-slate-500 mt-1">
                Provide accurate spatial coordinates for departmental triage and field officer navigation:
              </p>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                    Assigned Coordinates
                  </span>
                  <p className="font-mono text-sm font-semibold text-slate-900 mt-0.5">
                    {coords.lat.toFixed(6)}° N, {coords.lng.toFixed(6)}° E
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleAcquireLocation}
                  disabled={isLocating}
                  className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold px-3 py-2 rounded-md flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-60"
                >
                  <MapPin className="w-3.5 h-3.5 text-teal-400" />
                  {isLocating ? 'Acquiring GPS...' : 'Use Browser GPS'}
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="text-[11px] font-medium text-slate-600 block mb-1">Latitude</label>
                  <input
                    type="number"
                    step="0.0001"
                    value={coords.lat}
                    onChange={e => setCoords({ ...coords, lat: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs font-mono outline-hidden focus:border-teal-600"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-medium text-slate-600 block mb-1">Longitude</label>
                  <input
                    type="number"
                    step="0.0001"
                    value={coords.lng}
                    onChange={e => setCoords({ ...coords, lng: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs font-mono outline-hidden focus:border-teal-600"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-medium text-slate-600 block mb-1">Landmark / Street Address</label>
                <input
                  type="text"
                  value={addressText}
                  onChange={e => setAddressText(e.target.value)}
                  placeholder="Street name, landmark, near bus stop, school, or community hall..."
                  className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs outline-hidden focus:border-teal-600"
                />
              </div>
            </div>

            <div className="flex justify-between pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="border border-slate-300 hover:bg-slate-50 text-slate-700 px-4 py-2 rounded-lg text-xs font-medium flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> {t.forms.backBtn}
              </button>
              <button
                type="button"
                onClick={() => setStep(3)}
                className="bg-slate-900 hover:bg-slate-800 text-white px-5 py-2.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                {t.forms.nextBtn}: {t.forms.step3} <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Incident Details & Photo */}
        {step === 3 && (
          <div className="space-y-4">
            <div>
              <h3 className="font-bold text-base text-slate-900">3. {t.forms.step3}</h3>
              <p className="text-xs text-slate-500 mt-1">
                Describe the civic hazard and optionally attach photographic evidence:
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{t.forms.title}</label>
              <input
                type="text"
                required
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder={t.forms.titlePlaceholder}
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs outline-hidden focus:ring-1 focus:ring-teal-600 focus:border-teal-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{t.forms.description}</label>
              <textarea
                rows={4}
                required
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder={t.forms.descriptionPlaceholder}
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs outline-hidden focus:ring-1 focus:ring-teal-600 focus:border-teal-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{t.forms.uploadPhoto}</label>
              <div className="border-2 border-dashed border-slate-300 rounded-lg p-4 text-center hover:bg-slate-50 transition-colors">
                {imagePreview ? (
                  <div className="space-y-2">
                    <img
                      src={imagePreview}
                      alt="Uploaded preview"
                      className="max-h-48 mx-auto rounded object-cover border border-slate-200"
                    />
                    <button
                      type="button"
                      onClick={() => setImagePreview(null)}
                      className="text-xs text-rose-600 font-semibold hover:underline"
                    >
                      Remove Photo
                    </button>
                  </div>
                ) : (
                  <label className="cursor-pointer block">
                    <Camera className="w-8 h-8 text-slate-400 mx-auto mb-1" />
                    <span className="text-xs font-semibold text-slate-700 block">
                      Click to capture or select a photo from your device
                    </span>
                    <span className="text-[11px] text-slate-400 block mt-0.5">JPEG, PNG up to 8MB</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </label>
                )}
              </div>
            </div>

            <div className="flex justify-between pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="border border-slate-300 hover:bg-slate-50 text-slate-700 px-4 py-2 rounded-lg text-xs font-medium flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> {t.forms.backBtn}
              </button>
              <button
                type="button"
                disabled={!title.trim() || !description.trim() || isAnalyzing}
                onClick={triggerAiReview}
                className="bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white px-5 py-2.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                {isAnalyzing ? (
                  <>Processing Multimodal Analysis...</>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5 text-teal-300" /> {t.forms.evaluateAi}
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Step 4: AI Analysis & Risk Score Review */}
        {step === 4 && (
          <div className="space-y-4">
            <div>
              <h3 className="font-bold text-base text-slate-900">4. {t.forms.step4}</h3>
              <p className="text-xs text-slate-500 mt-1">
                Review automated extraction, explainable risk calculations, and safety boundaries before dispatch:
              </p>
            </div>

            {/* AI Summary Card */}
            {aiAnalysis && (
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 space-y-3 text-xs">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <div className="flex items-center gap-1.5 text-teal-800 font-bold">
                    <Sparkles className="w-4 h-4 text-teal-600" />
                    <span>Gemini Civic Triage Result</span>
                  </div>
                  <span className="font-mono text-slate-500">Confidence: {(aiAnalysis.confidence * 100).toFixed(0)}%</span>
                </div>

                <div>
                  <span className="font-bold text-slate-800 block">Structured Field Summary:</span>
                  <p className="text-slate-700 mt-0.5">{aiAnalysis.summary}</p>
                </div>

                <div>
                  <span className="font-bold text-slate-800 block">Extracted Physical Observations:</span>
                  <ul className="list-disc list-inside text-slate-600 space-y-0.5 mt-0.5">
                    {aiAnalysis.extractedObservations.map((obs, idx) => (
                      <li key={idx}>{obs}</li>
                    ))}
                  </ul>
                </div>

                {aiAnalysis.missingInformation.length > 0 && (
                  <div className="bg-amber-50/80 border border-amber-200 p-2.5 rounded text-amber-900">
                    <span className="font-bold block flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-700" /> Missing Operational Information for Officer:
                    </span>
                    <ul className="list-disc list-inside space-y-0.5 mt-0.5 text-[11px]">
                      {aiAnalysis.missingInformation.map((item, idx) => (
                        <li key={idx}>{item}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Explicit Safety Limitations */}
                <div className="bg-slate-100 p-2.5 rounded border border-slate-200 text-[11px] text-slate-600">
                  <span className="font-bold text-slate-700 block">Operational AI Limitation Disclaimer:</span>
                  <p className="mt-0.5 leading-relaxed">{aiAnalysis.limitations.join(' ')}</p>
                </div>
              </div>
            )}

            {/* Deterministic Risk Breakdown Card */}
            {calculatedRisk && (
              <div className="border border-slate-200 rounded-lg p-4 bg-white space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <span className="text-xs font-bold text-slate-800">
                    Deterministic Multi-Factor Priority Band:
                  </span>
                  <span
                    className={`text-xs font-bold px-2 py-0.5 rounded ${
                      calculatedRisk.band === 'URGENT'
                        ? 'bg-rose-100 text-rose-800'
                        : calculatedRisk.band === 'HIGH'
                        ? 'bg-orange-100 text-orange-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {calculatedRisk.band} ({calculatedRisk.score})
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px]">
                  <div className="bg-slate-50 p-2 rounded">
                    <span className="text-slate-500 block">Category Hazard</span>
                    <span className="font-mono font-semibold text-slate-800">
                      {calculatedRisk.breakdown.severity} (Weight: 25%)
                    </span>
                  </div>
                  <div className="bg-slate-50 p-2 rounded">
                    <span className="text-slate-500 block">Persistence Days</span>
                    <span className="font-mono font-semibold text-slate-800">
                      {calculatedRisk.breakdown.persistence} (Weight: 20%)
                    </span>
                  </div>
                  <div className="bg-slate-50 p-2 rounded">
                    <span className="text-slate-500 block">Civic Exposure</span>
                    <span className="font-mono font-semibold text-slate-800">
                      {calculatedRisk.breakdown.exposure} (Weight: 15%)
                    </span>
                  </div>
                </div>

                <div className="text-[11px] text-slate-600">
                  <span className="font-bold text-slate-700 block">Audit Explainability Factors:</span>
                  <ul className="list-disc list-inside mt-0.5 space-y-0.5">
                    {calculatedRisk.explanation.map((exp, i) => (
                      <li key={i}>{exp}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            <div className="flex justify-between pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setStep(3)}
                className="border border-slate-300 hover:bg-slate-50 text-slate-700 px-4 py-2 rounded-lg text-xs font-medium flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> {t.forms.backBtn}
              </button>
              <button
                type="button"
                disabled={isSubmitting}
                onClick={handleFinalSubmit}
                className="bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white px-6 py-2.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                {isSubmitting ? (
                  <>Registering Incident...</>
                ) : (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 text-teal-400" /> {t.forms.submitBtn}
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Step 5: Official Receipt Confirmation */}
        {step === 5 && submittedId && (
          <div className="text-center py-6 space-y-4">
            <div className="w-14 h-14 bg-teal-100 text-teal-700 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-xl font-bold text-slate-900">Incident Successfully Registered</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
                Your report has been written to the municipal database, categorized for departmental dispatch, and assigned an immutable tracking reference.
              </p>
            </div>

            <div className="inline-flex items-center gap-2 bg-slate-100 border border-slate-200 px-4 py-2 rounded-lg">
              <span className="text-xs text-slate-500">Tracking Reference:</span>
              <span className="font-mono text-sm font-bold text-slate-900">{submittedId}</span>
              <button
                type="button"
                onClick={handleCopyId}
                className="p-1 text-slate-500 hover:text-slate-800 rounded transition-colors"
                title="Copy Tracking ID"
              >
                <Copy className="w-3.5 h-3.5" />
              </button>
              {copied && <span className="text-[10px] text-teal-700 font-semibold">Copied!</span>}
            </div>

            <div className="pt-4 flex flex-wrap justify-center gap-3">
              <button
                type="button"
                onClick={() => {
                  setStep(1);
                  setTitle('');
                  setDescription('');
                  setImagePreview(null);
                  setAiAnalysis(null);
                  setCalculatedRisk(null);
                  setSubmittedId(null);
                }}
                className="border border-slate-300 hover:bg-slate-50 text-slate-700 px-4 py-2 rounded-lg text-xs font-semibold"
              >
                Report Another Hazard
              </button>
              {onGoToMap && (
                <button
                  type="button"
                  onClick={onGoToMap}
                  className="bg-slate-900 hover:bg-slate-800 text-white px-5 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5"
                >
                  <MapPin className="w-3.5 h-3.5 text-teal-400" /> View on Hyperlocal Map
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
