import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { FieldOfficerConsole } from './FieldOfficerConsole';
import { InteractiveCivicMap } from './InteractiveCivicMap';
import { CivicAIAssistant } from './CivicAIAssistant';
import {
  HardHat,
  MapPin,
  ClipboardCheck,
  Sparkles,
  Clock,
  CheckCircle2,
  ShieldCheck,
  AlertTriangle,
} from 'lucide-react';

export type FieldTab = 'active_tasks' | 'route_map' | 'history' | 'ai_assistant';

export const FieldOfficerWorkspace: React.FC = () => {
  const { currentUser, complaints, interventions, t, language } = useApp();
  const [activeTab, setActiveTab] = useState<FieldTab>('active_tasks');

  const myAssignedComplaints = complaints.filter(
    c => c.status !== 'RESOLVED' && (c.assignedOfficerName?.includes(currentUser.name.split(' ')[0]) || true)
  );

  const myInterventions = interventions.filter(
    i => i.officerName?.includes(currentUser.name.split(' ')[0]) || true
  );

  return (
    <div className="space-y-6 my-6">
      {/* Official Field Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white rounded-2xl p-6 border border-slate-700 shadow-xs flex flex-wrap justify-between items-center gap-4">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 bg-teal-500/20 text-teal-300 border border-teal-500/30 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider">
            <span>Municipal Field Unit</span> · <span>Zone 10 Sanitation Crew</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight">
            Officer {currentUser.name}
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl">
            Execute on-site culvert desilting, anti-larval chemical fogging, and container waste clearance. Log before/after photographic proof for citizen verification.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="font-mono text-xs bg-teal-950/60 text-teal-300 border border-teal-800 px-3 py-1.5 rounded-lg font-bold">
            {myAssignedComplaints.length} Work Orders Assigned
          </span>
        </div>
      </div>

      {/* Field Officer Exclusive Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto text-xs font-semibold">
        <button
          type="button"
          onClick={() => setActiveTab('active_tasks')}
          className={`px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'active_tasks'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <HardHat className="w-3.5 h-3.5 text-teal-400" />
          <span>Active Work Orders & Inspection</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('route_map')}
          className={`px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'route_map'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <MapPin className="w-3.5 h-3.5" />
          <span>Field Route Map</span>
          <span className="text-[10px] bg-teal-100 text-teal-800 px-1.5 py-0.2 rounded font-mono">Precision GPS</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('history')}
          className={`px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'history'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <ClipboardCheck className="w-3.5 h-3.5" />
          <span>Intervention Ledger ({myInterventions.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('ai_assistant')}
          className={`px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'ai_assistant'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-teal-400" />
          <span>Field Safety & SOP Assistant</span>
        </button>
      </div>

      {/* Tab 1: Active Tasks & Inspection Form */}
      {activeTab === 'active_tasks' && <FieldOfficerConsole />}

      {/* Tab 2: Route Map */}
      {activeTab === 'route_map' && <InteractiveCivicMap />}

      {/* Tab 3: Historical Intervention Log */}
      {activeTab === 'history' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
          <div>
            <h3 className="font-bold text-base text-slate-900">Recorded Field Interventions</h3>
            <p className="text-xs text-slate-500">
              Completed municipal actions logged on the tamper-evident ledger, awaiting citizen verification.
            </p>
          </div>

          <div className="divide-y divide-slate-100">
            {myInterventions.map(item => (
              <div key={item.id} className="py-4 space-y-2">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="font-mono text-xs font-bold text-slate-700">{item.trackingNumber}</span>
                    <h4 className="font-bold text-sm text-slate-900 mt-0.5">{item.interventionType}</h4>
                  </div>
                  <span className="text-xs text-slate-500">
                    {new Date(item.completedAt).toLocaleDateString()}
                  </span>
                </div>

                <p className="text-xs text-slate-600 bg-slate-50 p-2.5 rounded border border-slate-100">
                  {item.description}
                </p>

                <div className="flex items-center gap-4 text-[11px] text-slate-500">
                  <span>Officer: <strong>{item.officerName}</strong></span>
                  <span>·</span>
                  <span className="text-teal-700 font-semibold">
                    Verdict: {item.trendVerdict || 'IMPROVING'} (Confidence: {item.confidenceRating || 'HIGH'})
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: AI Assistant */}
      {activeTab === 'ai_assistant' && <CivicAIAssistant />}
    </div>
  );
};
