import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { LoginPortal } from './components/LoginPortal';
import { Navbar } from './components/Navbar';
import { CitizenWorkspace } from './components/CitizenWorkspace';
import { RepresentativeWorkspace } from './components/RepresentativeWorkspace';
import { FieldOfficerWorkspace } from './components/FieldOfficerWorkspace';
import { AnalystLab } from './components/AnalystLab';
import { AdminAuditLedger } from './components/AdminAuditLedger';
import { AlertCircle, CheckCircle2, Info } from 'lucide-react';

const AppContent: React.FC = () => {
  const { isAuthenticated, currentUser, t } = useApp();

  // If user is not authenticated, show the official Login Portal
  if (!isAuthenticated) {
    return <LoginPortal />;
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans selection:bg-teal-500 selection:text-white">
      {/* Top Academic & Prototype Notice Bar */}
      <aside
        aria-label="Academic Notice"
        className="bg-slate-900 text-slate-300 text-[11px] px-4 sm:px-6 py-1.5 border-b border-slate-800 flex flex-wrap justify-between items-center gap-2"
      >
        <div className="flex items-center gap-2 truncate">
          <span className="bg-amber-500/20 text-amber-300 font-bold px-2 py-0.5 rounded border border-amber-500/40 text-[10px] tracking-wide shrink-0">
            DEMONSTRATION PROTOTYPE
          </span>
          <span className="truncate">{t.academicNotice}</span>
        </div>
        <div className="text-[11px] text-slate-400 hidden md:block font-mono">
          Ward 10 Chennai Central Grid · Model: Gemini 3.8 Flash
        </div>
      </aside>

      {/* Main Role-Scoped Header */}
      <Navbar />

      {/* Role-Enforced Feature Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6">
        {currentUser.role === 'CITIZEN' && <CitizenWorkspace />}
        {currentUser.role === 'DEPT_OFFICER' && <RepresentativeWorkspace />}
        {currentUser.role === 'FIELD_OFFICER' && <FieldOfficerWorkspace />}
        {currentUser.role === 'HEALTH_ANALYST' && <AnalystLab />}
        {currentUser.role === 'SYS_ADMIN' && <AdminAuditLedger />}
      </main>

      {/* Municipal Platform Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 text-slate-500 text-xs mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row justify-between items-center gap-3">
          <p>
            © 2026 SwasthyaGrid (ஸ்வஸ்த்யாகிரிட்) · Greater Chennai Corporation & Tamil Nadu Urban Sanitation Framework.
          </p>
          <div className="flex items-center gap-3 text-[11px] text-slate-500">
            <span>Ward 10 Pilot Jurisdiction</span>
            <span aria-hidden="true">·</span>
            <span>Deterministic Triage & Gemini 3.8 Flash</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
