import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { UserRole, UserSession, Complaint, AuditLogEntry, CivicIntervention } from '../types';
import { translations } from '../utils/i18n';
import { INITIAL_COMPLAINTS, INITIAL_AUDIT_LOGS, INITIAL_INTERVENTIONS } from '../data/mockData';

export const PRESET_USERS: Record<UserRole, UserSession & { defaultEmail: string; roleLabel: string; roleLabelTa: string }> = {
  CITIZEN: {
    id: 'u-cit-01',
    name: 'M. Anand (ஆனந்த்)',
    email: 'citizen@swasthyagrid.tn.gov.in',
    defaultEmail: 'citizen@swasthyagrid.tn.gov.in',
    role: 'CITIZEN',
    roleLabel: 'Citizen / Resident',
    roleLabelTa: 'குடிமகன் / குடியிருப்புவாசி',
    isDemo: true,
  },
  DEPT_OFFICER: {
    id: 'u-dep-03',
    name: 'R. Priya (பிரியா - AEE Sanitation)',
    email: 'rep@swasthyagrid.tn.gov.in',
    defaultEmail: 'rep@swasthyagrid.tn.gov.in',
    role: 'DEPT_OFFICER',
    roleLabel: 'Ward Representative / Dept Officer',
    roleLabelTa: 'மக்கள் பிரதிநிதி / உதவி செயற்பொறியாளர்',
    departmentCode: 'CMWSSB',
    isDemo: true,
  },
  FIELD_OFFICER: {
    id: 'u-fld-02',
    name: 'K. Selvam (செல்வம்)',
    email: 'field@swasthyagrid.tn.gov.in',
    defaultEmail: 'field@swasthyagrid.tn.gov.in',
    role: 'FIELD_OFFICER',
    roleLabel: 'Municipal Field Officer',
    roleLabelTa: 'நகராட்சி களப்பணி அதிகாரி',
    departmentCode: 'SWD',
    isDemo: true,
  },
  HEALTH_ANALYST: {
    id: 'u-ana-04',
    name: 'Dr. S. Kugan (குகன் - Epidemiologist)',
    email: 'analyst@swasthyagrid.tn.gov.in',
    defaultEmail: 'analyst@swasthyagrid.tn.gov.in',
    role: 'HEALTH_ANALYST',
    roleLabel: 'Health & Risk Analyst',
    roleLabelTa: 'சுகாதார இடர் பகுப்பாய்வாளர்',
    isDemo: true,
  },
  SYS_ADMIN: {
    id: 'u-adm-05',
    name: 'Sundararajan (நிர்வாக அதிகாரி)',
    email: 'admin@swasthyagrid.tn.gov.in',
    defaultEmail: 'admin@swasthyagrid.tn.gov.in',
    role: 'SYS_ADMIN',
    roleLabel: 'System Administrator',
    roleLabelTa: 'கணினி தலைமை நிர்வாகி',
    isDemo: true,
  },
};

interface ToastNotification {
  id: string;
  type: 'success' | 'info' | 'warning' | 'error';
  message: string;
}

interface AppContextType {
  isAuthenticated: boolean;
  currentUser: UserSession;
  language: 'en' | 'ta';
  t: (typeof translations)['en'];
  complaints: Complaint[];
  auditLogs: AuditLogEntry[];
  interventions: CivicIntervention[];
  activeToast: ToastNotification | null;
  setLanguage: (lang: 'en' | 'ta') => void;
  login: (email: string, password?: string, role?: UserRole) => Promise<boolean>;
  logout: () => void;
  showToast: (message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  addComplaint: (complaint: Partial<Complaint>) => Promise<Complaint>;
  updateComplaintStatus: (id: string, status: Complaint['status'], remarks?: string, assignedOfficer?: string) => Promise<void>;
  addIntervention: (intervention: Partial<CivicIntervention>) => Promise<void>;
  refreshData: () => Promise<void>;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<'en' | 'ta'>('en');

  // Load authentication from localStorage if present
  // Never trust a browser-stored boolean for authentication. A server-validated token is required.
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);

  const [currentUser, setCurrentUser] = useState<UserSession>(() => {
    try {
      const stored = localStorage.getItem('sg_current_user');
      if (stored) return JSON.parse(stored);
    } catch {
      // Fallback
    }
    return PRESET_USERS.CITIZEN;
  });

  const [complaints, setComplaints] = useState<Complaint[]>(import.meta.env.PROD ? [] : INITIAL_COMPLAINTS);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(import.meta.env.PROD ? [] : INITIAL_AUDIT_LOGS);
  const [interventions, setInterventions] = useState<CivicIntervention[]>(import.meta.env.PROD ? [] : INITIAL_INTERVENTIONS);
  const [activeToast, setActiveToast] = useState<ToastNotification | null>(null);

  const showToast = useCallback((message: string, type: 'success' | 'info' | 'warning' | 'error' = 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    setActiveToast({ id, type, message });
    setTimeout(() => {
      setActiveToast(prev => (prev?.id === id ? null : prev));
    }, 4500);
  }, []);

  const refreshData = useCallback(async () => {
    const token = localStorage.getItem('sg_token');
    const headers: Record<string, string> = token ? { Authorization: `Bearer ${token}` } : {};
    try {
      const res = await fetch('/api/complaints', { headers });
      if (res.ok) setComplaints(await res.json());
    } catch {
      // Network failures are surfaced on attempted mutations; no local success is fabricated.
    }
    try {
      const resAudit = await fetch('/api/audit-logs', { headers });
      if (resAudit.ok) setAuditLogs(await resAudit.json());
    } catch {
      // Audit data remains unavailable while the API is offline.
    }
    try {
      const resInterventions = await fetch('/api/interventions', { headers });
      if (resInterventions.ok) setInterventions(await resInterventions.json());
    } catch {
      // Leave current view intact until the next server refresh.
    }
  }, []);


  const login = async (email: string, password: string = '', role?: UserRole): Promise<boolean> => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, role }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        showToast(data.error || data.detail?.message || 'Authentication failed. Check your credentials.', 'error');
        return false;
      }
      if (!data.user || !data.token) {
        showToast('The authentication server returned an invalid session response.', 'error');
        return false;
      }
      setCurrentUser(data.user);
      setIsAuthenticated(true);
      localStorage.setItem('sg_authenticated', 'true');
      localStorage.setItem('sg_current_user', JSON.stringify(data.user));
      localStorage.setItem('sg_token', data.token);
      showToast(language === 'ta' ? `${data.user.name} ஆக வெற்றிகரமாக உள்நுழைந்துள்ளீர்கள்!` : `Welcome back, ${data.user.name}!`, 'success');
      await refreshData();
      return true;
    } catch {
      showToast('Cannot reach the authentication server. No local login fallback is available.', 'error');
      return false;
    }
  };


  const logout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('sg_authenticated');
    localStorage.removeItem('sg_current_user');
    localStorage.removeItem('sg_token');
    showToast(language === 'ta' ? 'வெற்றிகரமாக வெளியேறிவிட்டீர்கள்.' : 'You have been safely signed out.', 'info');
  };

  const addComplaint = async (input: Partial<Complaint>): Promise<Complaint> => {
    const token = localStorage.getItem('sg_token');
    if (!token) throw new Error('Sign in with a valid server session before submitting a complaint.');
    try {
      const res = await fetch('/api/complaints', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ ...input, citizenId: currentUser.id, citizenName: currentUser.name }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || data.detail?.message || 'The server rejected this complaint.');
      const created: Complaint = data;
      setComplaints(prev => [created, ...prev]);
      showToast(`Complaint registered with ID: ${created.trackingNumber}`, 'success');
      await refreshData();
      return created;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'The server could not save this complaint.';
      showToast(`${message} No local success was recorded.`, 'error');
      throw err instanceof Error ? err : new Error(message);
    }
  };


  const updateComplaintStatus = async (
    id: string,
    status: Complaint['status'],
    remarks?: string,
    assignedOfficer?: string
  ) => {
    const token = localStorage.getItem('sg_token');
    if (!token) {
      showToast('Sign in with a valid server session before changing a case.', 'error');
      return;
    }
    try {
      const res = await fetch(`/api/complaints/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ status, remarks, actorName: currentUser.name, actorRole: currentUser.role, assignedOfficerName: assignedOfficer }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        showToast(data.error || data.detail?.message || `Unable to update to ${status}`, 'error');
        return;
      }
      const updated = data.complaint || data;
      setComplaints(prev => prev.map(c => (c.id === id ? updated : c)));
      showToast(`Status updated to ${status.replace(/_/g, ' ')}`, 'success');
      await refreshData();
    } catch {
      showToast('Cannot reach the case API. The status was not changed locally.', 'error');
    }
  };


  const addIntervention = async (intervention: Partial<CivicIntervention>) => {
    const token = localStorage.getItem('sg_token');
    if (!token) {
      showToast('Sign in with a valid server session before logging an intervention.', 'error');
      return;
    }
    try {
      const res = await fetch('/api/interventions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(intervention),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        showToast(data.error || data.detail?.message || 'Intervention could not be saved.', 'error');
        return;
      }
      setInterventions(prev => [data, ...prev]);
      showToast('Field intervention recorded on the server ledger.', 'success');
      await refreshData();
    } catch {
      showToast('Cannot reach the intervention API. Nothing was recorded locally.', 'error');
    }
  };


  return (
    <AppContext.Provider
      value={{
        isAuthenticated,
        currentUser,
        language,
        t: translations[language],
        complaints,
        auditLogs,
        interventions,
        activeToast,
        setLanguage,
        login,
        logout,
        showToast,
        addComplaint,
        updateComplaintStatus,
        addIntervention,
        refreshData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within an AppProvider');
  return ctx;
};
